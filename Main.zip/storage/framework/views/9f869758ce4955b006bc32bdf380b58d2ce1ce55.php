<?php /* /Users/jbazz/Documents/Lara/RoyalJoyam/resources/views/pages/dash/reportsview.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i> 
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/config">
          <i class="fa fa-cogs"></i>
          <p>Configuration</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/dashuser">
          <i class="fa fa-edit"></i>
          <p>Registry</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/waybill">
          <i class="fa fa-group"></i>
          <p>Waybill</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/sales">
          <i class="fa fa-euro"></i>
          <p>Sales</p>
        </a>
      </li>
      <li class="nav-item active2">
        <a class="nav-link" href="/reporting">
          <i class="fa fa-table"></i>
          <p>Reports</p>
        </a>
      </li>
      <!--li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-table"></i>
          <p>Null</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">library_books</i>
          <p>Null</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-envelope"></i>
          <p>Messaging</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">bubble_chart</i>
          <p>Help</p>
        </a>
      </li-->
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-11">

              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group row mb-0 hideMe">
                    <div class="col-md-5 offset-md-0 myTrim">
                      <div class="input-group no-border">
                        

                        <form action="<?php echo e(action('FeesController@store')); ?>" method="POST">
                          <?php echo csrf_field(); ?>

                        </form>

                      </div>
                    </div>
                </div>

                <div class="col-md-12 offset-md-0">

                    <div class="form-group row mb-0 searchRef">
                        <form class="salesForm" action="<?php echo e(action('ReportsController@index')); ?>" method="GET">
                          <?php echo csrf_field(); ?>
                          <div class="dropdown">

                            <input type="date" class="sref" name="date_from" placeholder="yyyy-mm-dd"/>
                            <input type="text" class="sref" name="" placeholder=" From - To " style="width:70px; border:none; padding:0" readonly/>
                            <input type="date" class="sref" name="date_to" placeholder="yyyy-mm-dd"/>
                            
                            <button type="submit" class="btn btn-info"></i> &nbsp; Load Data</button>
                            <a href="/reporting"><button type="button" class="btn btn-success" name="store_action" value="empty_cart"><i class="fa fa-refresh"></i></button></a>
                            <a href="/reportprinting"><button type="button" class="btn black" name="store_action" value="empty_cart"><i class="fa fa-print"></i></button></a>
                            
                          </div>

                        </form>
                    </div>

                </div>


                <div class="card">
                  <div id="printarea1" class="card-body">
              
                    <?php if(count($sales) > 0): ?>
                        <table class="table mt">
                          <thead class=" text-secondary hideMe">
                            <th>#</th>
                            <th>Order No.</th>
                            <th>User</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Pay Mode</th>
                            <th>Buyer's Name</th>
                            <th>Status</th>
                            <th>Date/Time Created</th>
                            <th class="ryt">Actions</th>
                          </thead>
                          <tbody id="tb">

                            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <?php if($sale->del == 'no'): ?>
                                
                                <?php if($c%2==0): ?>
                                  <?php if($sale->del_status == 'Not Delivered'): ?>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid != 'Paid'): ?>
                                      <tr class="debt_alert">
                                    <?php else: ?>
                                    <tr class="not_delivered">
                                    <?php endif; ?>
                                  <?php else: ?>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid != 'Paid'): ?>
                                      <tr class="debt_alert">
                                    <?php else: ?>
                                      <tr class="rowColour">
                                    <?php endif; ?>
                                  <?php endif; ?>
                                <?php else: ?>
                                  <?php if($sale->del_status == 'Not Delivered'): ?>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid != 'Paid'): ?>
                                      <tr class="debt_alert">
                                    <?php else: ?>
                                    <tr class="not_delivered">
                                    <?php endif; ?>
                                  <?php else: ?>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid != 'Paid'): ?>
                                      <tr class="debt_alert">
                                    <?php else: ?>
                                      <tr>
                                    <?php endif; ?>
                                  <?php endif; ?>
                                <?php endif; ?>
                                  <td><?php echo e($c++); ?></td>
                                  <td><?php echo e($sale->order_no); ?></td>
                                  <td><?php echo e($sale->user->name); ?><br><?php echo e($sale->user->status); ?></td>
                                  <td><?php echo e($sale->qty); ?></td>
                                  <td>GhC <?php echo e(number_format($sale->tot)); ?></td>
                                  <td><?php echo e($sale->pay_mode); ?><br>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid == 'Paid'): ?>
                                      <b><?php echo e($sale->paid); ?></b>
                                      &nbsp; <i class="fa fa-check" style="color: rgb(0, 163, 0)"></i>
                                    <?php endif; ?>
                                  </td>  
                                  <td><?php echo e($sale->buy_name); ?><br><?php echo e($sale->buy_contact); ?></td>
                                  <td><?php echo e($sale->del_status); ?></td>
                                  <td><?php echo e($sale->created_at); ?></td>  

                                  <form action="<?php echo e(action('ItemsController@update', $sale->id)); ?>" method="POST">
                                    <input type="hidden" name="_method" value="PUT">
                                    <?php echo csrf_field(); ?>

                                    <td><a href="/reporting/<?php echo e($sale->id); ?>"><button type="button" title="Print Order" class="print_black"><i class="fa fa-print"></i></button></a></td> 
                                  </form>

                                </tr>
                              
                              <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </tbody>
                        </table>
                        <p>No. of Records : <b style="color: #000000"><?php echo e(count($sales)); ?></b> &nbsp;&nbsp;&nbsp; Total Amount : <b style="color: #000000">GhC <?php echo e(number_format($cash + $cheque + $momo + $sum_dbt)); ?>.00</b></p>
                        
                        <?php echo e($sales->appends(['date_from' => request()->query('date_from'), 'date_to' => request()->query('date_to')])->links()); ?>


                        <div style="height: 30px">
                        </div>
      

                    <?php else: ?>
                      <p>No Records Found</p>
                    <?php endif; ?>
                  </div>
                </div>

                <form action="<?php echo e(url('/changedate')); ?>" method="GET">
                  <div class="form-group row mb-0 searchRef">
                    <input class="sref" id="item_no" name="date_today" type="date" style="height: 37px; margin: 5px" placeholder="yyyy-mm-dd"/>
                      <button type="submit" class="btn btn-primary"><i class="fa fa-calendar"></i> &nbsp; Change Today's Date</button>
                  </div>
                </form>
               
              <div class="container-fluid hideMe">

                <div class="row">
      
                  <div class="col-lg-3 col-md-6 col-sm-6">
                    <a data-toggle="modal" data-target="#totbreakdownModal" class="myA">
                      <div class="card card-stats">
                        <button class="btn salesBtn seablue"><i class="fa fa-warning salesI"></i></button>
                        <h4 class='config2'>GhC <?php echo e(number_format($b1)); ?>.00</h4>
                        
                        <div class="card-footer">
                          <div class="stats">Total Sales <?php echo e(Session::get('date_today')); ?><br>Profits: GhC&nbsp;<?php echo e(number_format($b1_profits)); ?>.00<br>Branch 1</div>
                        </div>
                      </div>
                    </a>
                  </div>
      
                  <div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="#" class="myA">
                      <div class="card card-stats">
                        <button class="btn salesBtn seablue"><i class="fa fa-warning salesI"></i></button>
                        <h4 class='config2'>GhC <?php echo e(number_format($b2)); ?>.00</h4>
                        
                        <div class="card-footer">
                          <div class="stats">Total Sales <?php echo e(Session::get('date_today')); ?><br>Profits: GhC&nbsp;<?php echo e(number_format($b2_profits)); ?>.00<br>Branch 2</div>
                        </div>
                      </div>
                    </a>
                  </div>

                  <div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="#" class="myA">
                      <div class="card card-stats">
                        <button class="btn salesBtn seablue"><i class="fa fa-warning salesI"></i></button>
                        <h4 class='config2'>GhC <?php echo e(number_format($b3)); ?>.00</h4>
                        
                        <div class="card-footer">
                          <div class="stats">Total Sales <?php echo e(Session::get('date_today')); ?><br>Profits: GhC&nbsp;<?php echo e(number_format($b3_profits)); ?>.00<br>Branch 3</div>
                        </div>
                      </div>
                    </a>
                  </div>
      
                  <div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="/expenses" class="myA">
                      <div class="card card-stats">
                        <button class="btn salesBtn pink"><i class="fa fa-money salesI"></i></button>
                        <h4 class='config2'>GhC <?php echo e(number_format($expenses->sum('expense_cost'))); ?>.00</h4>
                        
                        <div class="card-footer">
                          <div class="stats">Expenditure Report<br>All Branches</div>
                        </div>
                      </div>
                    </a>
                  </div>
      
                </div>

              </div>

            </div>


          </div>
        </div>
  </div>



  <div class="modal fade" id="totbreakdownModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Total Amount(GhC) Breakdown</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <table class="breakdown">
            <tr><td class="tt">Cash</td><td><b class="pr">GhC <?php echo e(number_format($cash)); ?></b>.00</td></tr>
            <tr><td class="tt">Cheque</td><td><b class="pr">GhC <?php echo e(number_format($cheque)); ?></b>.00</td></tr>
            <tr><td class="tt">Mobile Money</td><td><b class="pr">GhC <?php echo e(number_format($momo)); ?></b>.00</td></tr>
            <tr><td class="tt">Post Payment(Debt)</td><td><b class="pr">GhC <?php echo e(number_format($sum_dbt)); ?></b>.00</td></tr>
            <tr><td class="tt">Total Profits</td><td><b class="pr">GhC <?php echo e(number_format($gen_profits)); ?></b>.00</td></tr>
          </table>

        </div>
      </div>
    </div>
  </div>
  



<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript">
  $('#search').on('keyup',function(){
      $value=$(this).val();
      $.ajax({
          type : 'get',
          url : '<?php echo e(URL::to('/searchfee')); ?>',
          data:{'search':$value},
          success:function(data){
          $('#tb').html(data);
          }
      });
  })
</script>
<script type="text/javascript">
  $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>