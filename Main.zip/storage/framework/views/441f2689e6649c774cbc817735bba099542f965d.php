<?php /* /Users/jbazz/Documents/Lara/PivoResults/resources/views/pages/dash/addstudent.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/config">
          <i class="fa fa-cogs"></i>
          <p>Configuration</p>
        </a>
      </li>
      <li class="nav-item active2">
        <a class="nav-link" href="/addstudent">
          <i class="fa fa-group"></i>
          <p>Students</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="fa fa-edit"></i>
          <p>Registry</p>
        </a>
      <li class="nav-item ">
        <a class="nav-link" href="/fees">
          <i class="material-icons">content_paste</i>
          <p>Fees Mgt.</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-list"></i>
          <p>Attendance</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-table"></i>
          <p>Timetable</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">library_books</i>
          <p>Exam & Results</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-envelope"></i>
          <p>Messaging</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">bubble_chart</i>
          <p>Help</p>
        </a>
      </li>
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-7">

              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add Student</h4>
                  <p class="card-category">Complete student profile here..</p>
                </div>
                <div class="card-body">
            
                  <div class="container">
                      <div class="row justify-content-center">
                          <div class="col-md-8">
                            <div class="card-header">Register</div>
                  
                              <div class="card-body">

                                <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>

                                  <div class="form-group">
                                    <!--label for="cat-title" class="col-form-label">Title:</label-->
                                    <input type="text" class="form-control" name="fname" placeholder="Firstname" required/>
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="sname" placeholder="Other names" required/>
                                  </div>
                                  
                                  <label for="" class="col-form-label smalllable">Date of Birth: </label>
                                  <div class="form-group">
                                  <input type="date" class="form-control" name="dob" placeholder="dd-mm-YYYY"/>
                                  </div>
                                  <div class="form-group">
                                    <label for="recipient-name" class="col-form-label">Gender:</label>
                                    <select name="sex" class="form-control" id="sex">
                                      <option>Male</option>
                                      <option>Female</option>
                                    </select>
                    
                                  </div>
                      
                                  <div class="form-group">
                                    <label for="recipient-name" class="col-form-label">Class:</label>
                                    <select name="std_cls" class="form-control" id="std_cls">
                                      <?php if(count($stages) > 0): ?>
                                        <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($stage->del != 'yes'): ?>
                                            <option><?php echo e($stage->cls_name); ?></option>
                                          <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php endif; ?>
                                    </select>
                                  </div>

                                  <div class="form-group">
                                    <input type="text" class="form-control" name="guardian" placeholder="Guardian's Full Name" required/>
                                  </div>
                      
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="contact" placeholder="Contact No." required/>
                                  </div>
                                  <div class="form-group">
                                    <input type="email" class="form-control" name="email" placeholder="Email" />
                                  </div>
                                  
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="residence" placeholder="Place of Recidence"/>
                                  </div>
                      
                                  <div class="">
                                    <label class="upfiles">Upload Photo: &nbsp; </label>
                                    <input type="file" name="std_img">
                                  </div>

                                  <div class="form-group">
                                    <input id="bill_total" type="text" class="form-control selected_courses myReadonly" name="bill_total" placeholder="Bill Total: GhC 0" readonly required/>
                                  </div>
                                  
                                  <div class="modal-footer">
                                    <button type="submit" class="btn btn-info" name="store_action" value="admi_create_std"><i class="fa fa-save"></i> &nbsp; Save</button>
                                  </div>
                                </form>

                                

                              </div>
                                 
                            </div>
                              
                          </div>
                      </div>
                  </div>
                </div>
            </div>

            
            <div class="col-md-5">
              <div class="card card-profile">
                <div class="card-body">
                  <h4 class="card-title">Add Students From Excel File</h4>

                  <form action="<?php echo e(action('ImportsController@store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    
                    <div class="col-md-10 offset-md-1">
      
                      <div class="">
                        <label class="upfiles">Upload File Here: &nbsp; </label>
                        <input type="file" name="import_file" required>
                      </div>
                      
                      <p>Click <a href="/download">Here</a> to download excel file format</p>

                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" name="store_action" value="import_std"><i class="fa fa-save"></i> &nbsp; Upload File</button>
                      </div>

                    </div>

                  </form>
                   
                </div>
              </div>

                  <div style="height: 30px">
                  </div>

              <div class="card card-profile">
                <div class="card-body">
                  <h4 class="card-title">Add Items To Bill</h4>

                          <?php if(count($payables) > 0): ?>
                            <table class="table">
                              <thead class="text-secondary">
                                <th></th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Cost</th>
                                <th class="ryt">
                                  Action
                                </th>
                              </thead>
                              <tbody>
 
                                <script>var hold = ''; var hold2 = parseInt(0);</script>

                              <?php $__currentLoopData = $payables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr><td><?php echo e($i++); ?></td>
                                    <td><?php echo e($payable->name); ?></td>
                                    <td><?php echo e($payable->desc); ?></td>
                                    <td><?php echo e($payable->cost); ?></td>
                                    <td class="ryt">
                                      <form action="<?php echo e(action('StudentController@destroy', $payable->id)); ?>" method="POST">

                                        <input type="checkbox" class="checkbox1" id="myCheck<?php echo e($i); ?>" name="" value="<?php echo e($payable->cost); ?>" onclick="myFunction<?php echo e($i); ?>()">
                                        <input type="text" style="display: none" id="myCheck2<?php echo e($i); ?>" value="<?php echo e($payable->name); ?>">

                                        <input type="hidden" name="_method" value="DELETE">
                                        <?php echo csrf_field(); ?>

                                        <button type="submit" name="sub_action" value="crs_del" rel="tooltip" title="Delete Course" class="close2" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa fa-close"></i></button>
                                      
                                        <p id="text<?php echo e($i); ?>" style="display:none">Checked<?php echo e($i); ?></p>
                                        <p id="demo<?php echo e($i); ?>"></p>

                                        <script>
                                          function myFunction<?php echo e($i); ?>(){
                                            var checkBox = document.getElementById('myCheck<?php echo e($i); ?>')
                                            var BoxValue = document.getElementById('myCheck<?php echo e($i); ?>').value;
                                            var BoxValue2 = document.getElementById('myCheck2<?php echo e($i); ?>').value;
                                            var text = document.getElementById('text<?php echo e($i); ?>')
                                            var txt_input = document.getElementById('txt_input')

                                            var bill_total = document.getElementById('bill_total')


                                            if (checkBox.checked == true){

                                              hold2 = hold2 + parseInt(BoxValue);
                                              bill_total.value = hold2;


                                              hold = hold + ',' + BoxValue2;
                                              var getR = txt_input.value;
                                              if (getR == ''){
                                                txt_input.value = BoxValue2 + ',';
                                              }else{
                                                txt_input.value = getR + BoxValue2 + ',';
                                              }

                                            }else{

                                              hold2 = hold2 - BoxValue;
                                              bill_total.value = hold2;

                                              //text.style.display = 'none';

                                              BoxValue2 = BoxValue2 + ',';
                                              var getR =  document.getElementById('txt_input').value;
                                              getR = getR.replace(BoxValue2, '');
                                              txt_input.value = getR;

                                            }

                                          }
                                        </script>
                                      
                                      </form>
                                    </td>
                                  </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>

                            <p id="receiver" style="display:none">A</p>
                            <input id="txt_input" type="text" class="form-control selected_courses myReadonly" name="name" placeholder="Selected items will be added to bill" readonly required/>
                            
                          <?php else: ?>
                            <p>No Items Registered</p>
                          <?php endif; ?>

                </div>
              </div>

                  <div style="height: 30px">
                  </div>

                  <div class="modal-footer">
                    <a href="/students"><button type="submit" class="btn btn-info" name="store_action" value="admi_upload_std"><i class="fa fa-folder-open"></i> &nbsp; All Students</button></a>
                  </div>

              <div class="form-group row mb-0">
                <div class="col-md-3 offset-md-0">
                </div>

                

                <script>
                  function getFunction(){
                      var textarea = document.getElementById('txt_area')
                      var getData =  document.getElementById('txt_input').value;
                      textarea.value = getData;
                    }
                </script>

              </div>

            </div>

          </div>
        </div>
  </div>


  <div class="modal fade" id="clsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Confirm Class & Course Registeration</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <div class='col-md-10 offset-md-1'>
          <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            

            <div class="form-group">
             
              <label class="col-form-label">Choose Class</label>
              <select name="cls_name" class="form-control" id="cls_name">
                <?php if(count($stages) > 0): ?>
                  <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($stage->del != 'yes'): ?>
                      <option><?php echo e($stage->cls_name); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
              
              <label class="col-form-label">Selected Subjects</label>
              <div class="form-group">
                <textarea name="sel_sub" id="txt_area" class="form-control myReadonly" placeholder="Course Description" rows="3" readonly></textarea>
              </div>

              <label class="col-form-label">Class Teacher/Lecturer</label>
              <select name="cls_tch" class="form-control" id="assign_tch">
                <option selected>Not Assigned</option>
                <option>Teacher 1</option>
                <option>Teacher 2</option>
                <option>Teacher 3</option>
              </select>

              

            </div>

            
      
            <div class="modal-footer">
              <button type="submit" class="btn btn-info" name="store_action" value="admi_create_cls"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>
          </div>

        </div>
        <!--div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Send message</button>
        </div-->
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>