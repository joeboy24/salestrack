<?php /* /Users/jbazz/Documents/Lara/abundantlife/resources/views/pages/dash/department.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item ">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/dashuser">
          <i class="material-icons">person</i>
          <p>Users</p>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="/department">
          <i class="material-icons">assignment</i>
          <p>Departments</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/members">
          <i class="fa fa-users"></i>
          <p>Members</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/tithes">
          <i class="material-icons">content_paste</i>
          <p>Tithe</p>
        </a>
      </li>
      <!--li class="nav-item ">
        <a class="nav-link" href="/galleryview">
          <i class="material-icons">image</i>
          <p>Gallery</p>
        </a>
      <li class="nav-item ">
        <a class="nav-link" href="/posts">
          <i class="material-icons">library_books</i>
          <p>Posts</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./icons.html">
          <i class="material-icons">bubble_chart</i>
          <p>Icons</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./map.html">
          <i class="material-icons">location_ons</i>
          <p>Maps</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./notifications.html">
          <i class="material-icons">notifications</i>
          <p>Notifications</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./rtl.html">
          <i class="material-icons">language</i>
          <p>RTL Support</p>
        </a>
      </li-->
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-7">

          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add Department</h4>
                  <p class="card-category">Register each department here..</p>
                </div>
                <div class="card-body">
            
                  <div class="container">
                      <div class="row justify-content-center">
                          <div class="col-md-8">
                              
                                  <div class="card-header">Register</div>
                  
                                  <div class="card-body">
                                      <form action="<?php echo e(action('PostsController@store')); ?>" method="POST">
                                          <?php echo csrf_field(); ?>
                  
                                          <div class="form-group row">
                  
                                              <div class="col-md-12">
                                                  <input id="name" placeholder="Name" type="text" class="form-control" name="name" required autofocus>
                                              </div>
                                          </div>
                  
                                          <div class="form-group row">
                  
                                              <div class="col-md-12">
                                                  <textarea id="desc" placeholder="Description" class="form-control" name="desc" rows="2"></textarea>
                                              </div>
                                          </div>
                  


                                          <div class="form-group row mb-0">
                                              <div class="col-md-6 offset-md-4">
                                                  <button type="submit" class="btn btn-info" name="store_action" value="create_dept"><i class="fa fa-save"></i> &nbsp; Add Department</button>
                                              </div>
                                          </div>
                                      </form>
                                  </div>
                              
                          </div>
                      </div>
                  </div>

                </div>
              </div>
            </div>


            
            <div class="col-md-5">
              <div class="card card-profile">
                <div class="card-body">
                  


                  <?php if(count($depts) > 0): ?>
                            <table class="table">
                              <thead class=" text-primary">
                                <th>ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th class="ryt">
                                  Action
                                </th>
                              </thead>
                              <tbody>
                              <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr><td><?php echo e($dept->id); ?></td>
                                    <td><?php echo e($dept->name); ?></td>
                                    <td><?php echo e($dept->desc); ?></td>
                                    <td class="ryt">
                                      <form action="<?php echo e(action('MembersController@destroy', $dept->id)); ?>" method="POST">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <?php echo csrf_field(); ?>

                                        <button type="submit" name="sub_action" value="dept_del" rel="tooltip" title="Delete Department" class="close2" onclick="return confirm('Are you sure you want to delete this department?');"><i class="fa fa-close"></i></button>
                                      </form>
                                    </td>
                                  </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                            <?php else: ?>
                              <p>No Department Added Yet</p>
                            <?php endif; ?>




                </div>
              </div>
            </div>
          </div>
        </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>