<?php /* /Users/jbazz/Documents/Lara/PivoResults/resources/views/pages/dash/studentsview.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/config">
          <i class="fa fa-cogs"></i>
          <p>Configuration</p>
        </a>
      </li>
      <li class="nav-item active2">
        <a class="nav-link" href="/addstudent">
          <i class="fa fa-group"></i>
          <p>Students</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="fa fa-edit"></i>
          <p>Registry</p>
        </a>
      <li class="nav-item">
        <a class="nav-link" href="/fees">
          <i class="material-icons">content_paste</i>
          <p>Fees Mgt.</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-list"></i>
          <p>Attendance</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-table"></i>
          <p>Timetable</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">library_books</i>
          <p>Exam & Results</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-envelope"></i>
          <p>Messaging</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">bubble_chart</i>
          <p>Help</p>
        </a>
      </li>
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-11">

              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group row mb-0 hideMe">

                  <div class="col-md-5 offset-md-0 myTrim">

                    <form style="width: 400px" method="GET" action="<?php echo e(url('/students')); ?>">
                      <div class="input-group no-border">
                        

                          <input type="search" value="" class="form-control search_field" id="searchquery" name="searchquery" placeholder="Search Records...">
                          
                          <button type="submit" class="btn btn-white btn-round my_bt">
                            <i class="material-icons">search</i>
                            <div class="ripple-container"></div>
                          </button>

                          <a href="/students" class="refresh_a"><button type="submit" class="btn btn-success btn-round" id="mb">
                            <i class="fa fa-refresh"></i>
                            <div class="ripple-container"></div>
                          </button></a>
                          
                      </div>
                    </form>
                      
                  </div>
                  <div class="col-md-7 offset-md-0 myTrim">
                    <a href="/studentsrecycler"><button type="submit" class="btn btn-white pull-right" title="Recycle Bin"><i class="fa fa-trash"></i></button></a>
                    <a href="/addstudent"><button type="submit" class="btn btn-white pull-right" ><i class="fa fa-arrow-left"></i></button></a>
                    
                  </div>

                </div>

              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">All Students</h4>
                  
                </div>
                <div id="printarea1" class="card-body">
            
                    <?php if(count($students) > 0): ?>
                        <table class="table">
                          <thead class=" text-secondary hideMe">
                            <th>#</th>
                            <th>Id</th>
                            <th>Fullame</th>
                            <th>Gender</th>
                            <th>Birth Date</th>
                            <th>Class</th>
                            <th>Guardian</th>
                            <th>G.Contact</th>
                            <th>Email</th>
                            <th>Residence</th>
                            <th>Bill (GhC)</th>
                            <th>User</th>
                            <th>Date & Time</th>
                            <th class="ryt">Actions</th>
                          </thead>
                          <tbody id="tb">
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($c%2==0): ?>
                                <tr class="rowColour"><td><?php echo e($c++); ?></td>
                              <?php else: ?>
                                <tr><td><?php echo e($c++); ?></td>
                              <?php endif; ?>
                                  <td><?php echo e($student->std_id); ?></td>
                                  <td><?php echo e($student->fname.' '.$student->sname); ?></td>
                                  <td><?php echo e($student->sex); ?></td>
                                  <td><?php echo e($student->dob); ?></td>
                                  <td><?php echo e($student->class); ?></td>
                                  <td><?php echo e($student->guardian); ?></td>
                                  <td><?php echo e($student->contact); ?></td>
                                  <td><?php echo e($student->email); ?></td>
                                  <td><?php echo e($student->residence); ?></td>
                                  <td><?php echo e($student->bill); ?></td>
                                  <td><?php echo e($student->user->name); ?></td>
                                  <td><?php echo e($student->created_at); ?></td>
                                  <td class="ryt">
                                    
                                    <form action="<?php echo e(action('StudentController@update', $student->id)); ?>" method="POST" enctype="multipart/form-data">
                                      <input type="hidden" name="_method" value="PUT">
                                      <?php echo csrf_field(); ?>


                                      <a href="" class="edit" data-toggle="modal" rel="tooltip" title="Edit Record" data-target="#edit_<?php echo e($student->id); ?>"><i class="fa fa-pencil"></i></a>
                                      
                                      <button type="submit" name="sub_action" value="std_del" rel="tooltip" title="Delete Student" class="close2" onclick="return confirm('Fees records will be deleted as well.. Are you sure?');"><i class="fa fa-close"></i></button>
                                    

                                      <div class="modal fade" id="edit_<?php echo e($student->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modtop" role="document">
                                          <div class="modal-content">
                                              
                                              <div class="card card-profile">
                                                <div class="card-avatar">
                                                  <a href="#pablo">
                                                  <img class="img" src="/storage/std_imgs/<?php echo e($student->photo); ?>" />
                                                  </a>
                                                </div>
                                                <div class="card-body">
                                                  <h4 class="card-category text-gray">STUDENT ID: <?php echo e($student->std_id); ?></h4>
                                                  <h6 class="card-title">Created by: <?php echo e($student->user->name); ?></h6>




                                                  <table class="user_view_tbl">
                                                    <tbody>

                                                      <tr class="tbl_tr"><td class="tl">Firstname</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="text" class="form-control" name="fname" placeholder="Firstname" value="<?php echo e($student->fname); ?>" required/>
                                                        </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Other names</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="text" class="form-control" name="sname" placeholder="Other names" value="<?php echo e($student->sname); ?>" required/>
                                                        </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Birth Date</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type='date' class="form-control" placeholder="YYYY-MM-DD" name="dob" value="<?php echo e($student->dob); ?>"/>
                                                          </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Gender</td><td class="tr">
                                                        <div class="form-group">
                                                          <select name="sex" class="form-control" id="sex">
                                                            <option selected><?php echo e($student->sex); ?></option>
                                                            <option>Male</option>
                                                            <option>Female</option>
                                                          </select>
                                                        </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Class</td><td class="tr">
                                                        <div class="form-group">
                                                          <select name="std_cls" class="form-control" id="std_cls">
                                                            <option selected><?php echo e($student->class); ?></option>
                                                            <?php if(count($stages) > 0): ?>
                                                            <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <?php if($stage->del != 'yes'): ?>
                                                                <option><?php echo e($stage->cls_name); ?></option>
                                                              <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                          <?php endif; ?>
                                                          </select>
                                                        </div>
                                                      </td></tr>


                                                      <tr class="tbl_tr"><td class="tl">Guardian's Name</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="text" class="form-control" name="guardian" placeholder="Guardian's Full Name" value="<?php echo e($student->guardian); ?>" required/>
                                                        </div>
                                                      </td></tr>


                                                      <tr class="tbl_tr"><td class="tl">Contact</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="text" class="form-control" name="contact" placeholder="Contact No." value="<?php echo e($student->contact); ?>" required/>
                                                        </div>
                                                      </td></tr>


                                                      <tr class="tbl_tr"><td class="tl">Email</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e($student->email); ?>"/>
                                                        </div>
                                                      </td></tr>
                                                      
                                                      <tr class="tbl_tr"><td class="tl">Residence</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="text" class="form-control" name="residence" placeholder="Place of Recidence" value="<?php echo e($student->residence); ?>"/>
                                                        </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Photo</td><td class="tr">
                                                        <div class="">
                                                          <input type="file" name="std_img">
                                                        </div>
                                                      </td></tr>

                                                          <input type="hidden" name="photo" value="<?php echo e($student->photo); ?>"/>

                                                      <tr class="tbl_tr"><td class="tl">Bill</td><td class="tr">
                                                        <div class="form-group">
                                                          <input id="bill_total" type="text" class="form-control" name="bill_total" placeholder="Current Bill Total: GhC <?php echo e($student->bill); ?>.00" value="<?php echo e($student->bill); ?>"  required/>
                                                        </div>  
                                                      </td></tr>

                                                    </tbody>
                                                  </table>


                                                                   

                                                </div>
                                              </div>
                                              
                                              <div class="modal-footer">
                                                <button type="submit" class="btn btn-info" name="sub_action" value="update_student"><i class="fa fa-save"></i> &nbsp; Update Record</button>
                                              </div>

                                          </div>
                                    
                                        </div>
                                      </div>

                                    </form>                  
                                    
                                  </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                        <p>Student Population : <b style="color: #000000"><?php echo e($std_pop); ?></b></p>
                        
                        <?php echo e($students->appends(['searchquery' => request()->query('searchquery')])->links()); ?>


                        <div style="height: 30px">
                        </div>
      
                    

                    <?php else: ?>
                      <p>No Records Found</p>
                    <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>

  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript">
  $('#search').on('keyup',function(){
      $value=$(this).val();
      $.ajax({
          type : 'get',
          url : '<?php echo e(URL::to('searchstudent')); ?>',
          data:{'search':$value},
          success:function(data){
          $('#tb').html(data);
          }
      });
  })
</script>
<script type="text/javascript">
  $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>