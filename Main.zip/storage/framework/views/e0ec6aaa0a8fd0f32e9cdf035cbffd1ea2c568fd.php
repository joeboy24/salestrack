<?php /* /Users/klasique/lara53/resources/views/pages/dash/postsview.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item  ">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="material-icons">person</i>
          <p>Uses</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/members">
          <i class="fa fa-users"></i>
          <p>Members</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/galleryview">
          <i class="material-icons">image</i>
          <p>Gallery</p>
        </a>
      <li class="nav-item active ">
        <a class="nav-link" href="/posts">
          <i class="material-icons">library_books</i>
          <p>Posts</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/tithes">
          <i class="material-icons">content_paste</i>
          <p>Tithe</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./icons.html">
          <i class="material-icons">bubble_chart</i>
          <p>Icons</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./map.html">
          <i class="material-icons">location_ons</i>
          <p>Maps</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./notifications.html">
          <i class="material-icons">notifications</i>
          <p>Notifications</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./rtl.html">
          <i class="material-icons">language</i>
          <p>RTL Support</p>
        </a>
      </li>
      <li class="nav-item active-pro ">
        <a class="nav-link" href="./upgrade.html">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">     

      <div class="row">
        <div class="col-md-12">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">POSTS</h4>
              <p class="card-category"> Here is a list of all posts & actions</p>
            </div>
            <div class="card-body">
              <button type="submit" class="btn btn-primary pull-right" data-toggle="modal" data-target="#postModal"><i class="fa fa-plus"></i>&nbsp;&nbsp; Add Post</button>
              <button type="submit" class="btn btn-success pull-right" data-toggle="modal" data-target="#catgModal"><i class="fa fa-sitemap"></i>&nbsp;&nbsp; Add Catg</button>
              <div class="table-responsive">

                
                        
                            <?php if(count($posts) > 0): ?>
                            <table class="table">
                              <thead class=" text-primary">
                                <th>Title</th>
                                <th>Body</th>
                                <th>Category</th>
                                <th>Date</th>
                                <th class="ryt">
                                  Actions
                                </th>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($post->del != 'yes'): ?>
                                        <tr>
                                          <td><?php echo e($post->title); ?></td>
                                          <td><?php echo e(substr($post->body,0,20).'. . .'); ?></td>
                                          <td><?php echo e($post->post_cat); ?></td>
                                          <td><?php echo e($post->created_at); ?></td>
                                          <td class="ryt">
                                
                                            <form action="<?php echo e(action('PostsController@update', $post->id)); ?>" method="POST" class="float-right">
                                              <input type="hidden" name="_method" value="PUT">
                                              <?php echo csrf_field(); ?>

                                              <button type="submit" name="sub_action" value="del" class="close2" title="Open" onclick="return confirm('Are you sure you want to delete this post?');"><i class="fa fa-close"></i></button>
                                              <a href="/posts/<?php echo e($post->id); ?>/edit" title="Edit" class="edit"><i class="fa fa-pencil"></i></a>
                                              <button type="button" class="view2" title="View" data-toggle="modal" data-target="<?php echo e('#hold'.$post->id); ?>"><i class="fa fa-folder-open"></i></button>
                                              <!--textarea class="form-control" id="article-ckeditor" name="body" placeholder="Body/Text" rows="5"></textarea-->
                                            </form>


                                          <div class="modal fade" id="<?php echo e('hold'.$post->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                              <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                  <div class="modal-header">
                                                      <h2 class="modal-title" id="exampleModalLabel"><i class="fa fa-dot-circle-o"></i>&nbsp;&nbsp; <?php echo e($post->title); ?></h2>
                                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                      </button>
                                                  </div>
                                                  <div class="modal-body">
                                                    <p class="mm"><?php echo e($post->body); ?>. <br> <small style="color:darkturquoise";>. . . Written on <?php echo e(date('M-d-Y', strtotime($post->created_at))); ?> at <?php echo e(date('H:i', strtotime($post->created_at))); ?>.</small></p>
                                                    <div><img class="mm_img" src="../storage/cover_imgs/<?php echo e($post->cover_img); ?>"></div>
                                                    <h3 class="mm"><?php echo e($post->title2); ?></h3>
                                                    <p class="mm"><?php echo e($post->body2); ?></p>
                                                    <div class="fl"><img class="mm_img2n3" src="../storage/cover_imgs/<?php echo e($post->cover_img2); ?>"></div>
                                                    <div class="fr"><img class="mm_img2n3" src="../storage/cover_imgs/<?php echo e($post->cover_img3); ?>"></div>
                                                    
                                                  </div>
                                                  <!--div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="button" class="btn btn-primary">Send message</button>
                                                  </div-->
                                                </div>
                                              </div>
                                            </div>


                                          </td>
                                        </tr>
                                  <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                            <?php else: ?>
                              <p>No Posts found</p>
                            <?php endif; ?>


                        <div class="paginationx"><?php echo e($posts->links()); ?></div>

              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>


  <div class="modal fade" id="catgModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Add Post Category Here</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(action('PostsController@store')); ?>" method="POST"  enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <input type="text" class="form-control" id="cat-title" name="cat_name" placeholder="Category Title">
            </div>
            <div class="form-group">
              <textarea class="form-control" id="message-text" name="cat_desc" maxlength="100" placeholder="Category Description"></textarea>
            </div>

            <div class="">
              <label class="upfiles">Cover Image: &nbsp; </label>
              <input type="file" name="pcov_img" required>
            </div>
            
            <div class="modal-footer">
              <button type="submit" class="btn btn-success" name="store_action" value="sub_cat"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  
  <div class="modal fade" id="postModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Add Post Here</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form action="<?php echo e(action('PostsController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <!--label for="cat-title" class="col-form-label">Title:</label-->
              <input type="text" class="form-control" name="title" placeholder="Tittle" required/>
            </div>
            <div class="form-group">
              <textarea name="body" id="article-ckeditorr" class="form-control" placeholder="Body/Text" rows="5" required></textarea>
            </div>

            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Choose Image Category:</label>
              <select name="cat" class="form-control" id="cat">
              <?php $__currentLoopData = $pcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option><?php echo e($pcat->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="">
              <label class="upfiles">Cover Image 1: &nbsp; </label>
              <input type="file" name="cover_img" required>
            </div>
            <label class="upfiles">Additional Details Below(If Any)</label>
            <div class="form-group">
              <input type="text" class="form-control" name="title2" placeholder="Additional Tittle" />
            </div>
            <div class="form-group">
              <textarea name="body2" id="article-ckeditorr" class="form-control" placeholder="Additional Body/Text" rows="5"></textarea>
            </div>

            <div class="">
              <label class="upfiles">Cover Image 2: &nbsp; </label>
              <input type="file" name="cover_img2" class="upfiles">
            </div>

            <div class="">
              <label class="upfiles">Cover Image 3: &nbsp; </label>
              <input type="file" name="cover_img3" class="upfiles">
            </div>
            
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary" name="store_action" value="create_post"><i class="fa fa-save"></i> &nbsp; Submit</button>
            </div>
          </form>

        </div>
        <!--div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Send message</button>
        </div-->
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>