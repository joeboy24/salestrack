<?php /* /Users/jbazz/Documents/Lara/PivoResults/resources/views/pages/dash/resultcheck.blade.php */ ?>
<html>
    <head>
        <link href="/dashdir/css/material-dashboard.css?v=2.1.1" rel="stylesheet" />
    </head>

    <body>
        <div class="row">
            <div class="col-md-8 offset-md-2">

                <div class="card">

                    <div class="card-body">

                        <div class="result_header">
                            
                            <?php if(count($company) > 0): ?>
                                <h3 class="card-title"><?php echo e($company->name); ?></h3>
                                <p class="card-category text-gray pp"><?php echo e($company->address); ?></p>
                                <p class="card-category text-gray pp">Contact: <?php echo e($company->contact.' / Email: '.$company->email); ?></p>
                                <h4 class="card-title">End of Term <?php echo e($company->ac_term); ?> Report</h4>
                            <?php else: ?>
                                <h3 class="card-title">School name not set</h3>
                                <p class="card-category text-gray pp">school address not set</p>
                                <p class="card-category text-gray pp">Contact: Not set / Email: Not set</p>
                                <h4 class="card-title">End of Term Report</h4>
                            <?php endif; ?>

                        </div> 
                        
                        <div class="row">          

                            <div class="col-md-3">
                                <img class="result_image_container" src="/maindir/image/S4.jpg">
                                <div class="report_img_txt">
                                    <p>ID: 202112</p>
                                    <p><b>Eleaser Johnson</b></p>
                                    <p>JHS 1B</p>
                                </div>
                            </div>

                            <div class="col-md-8">

                                <table class="results_tbl">
                                    <thead>
                                        <th class="res_sub">Subject</th>
                                        <th>Class Score 30%</th>
                                        <th>Exam Score 70%</th>
                                        <th>Total</th>
                                        <th>Grade</th>
                                        <th>Pos.</th>
                                        <th class="remark">Remark</th>
                                    </thead>
                                    <tbody>
                                        <tr><td class="res_sub">English Language</td>
                                            <td>27</td>
                                            <td>68</td>
                                            <td>95</td>
                                            <td>A</td>
                                            <td>2nd</td>
                                            <td class="remark">Excellent</td>
                                        </tr>
                                        <tr><td class="res_sub">Core Mathematics</td>
                                            <td>27</td>
                                            <td>67</td>
                                            <td>94</td>
                                            <td>A</td>
                                            <td>1st</td>
                                            <td class="remark">Excellent</td>
                                        </tr>
                                        <tr><td class="res_sub">Integrated Science</td>
                                            <td>24</td>
                                            <td>65</td>
                                            <td>89</td>
                                            <td>B+</td>
                                            <td>7th</td>
                                            <td class="remark">Very Good</td>
                                        </tr>
                                        <tr><td class="res_sub">Social Studies</td>
                                            <td>24</td>
                                            <td>50</td>
                                            <td>74</td>
                                            <td>C-</td>
                                            <td>7th</td>
                                            <td class="remark">Good</td>
                                        </tr>
                                        <tr><td class="res_sub">Catering</td>
                                            <td>17</td>
                                            <td>40</td>
                                            <td>57</td>
                                            <td>D</td>
                                            <td>21st</td>
                                            <td class="remark">Poor</td>
                                        </tr>
                                        <tr><td class="res_sub">Ceramics</td>
                                            <td>20</td>
                                            <td>55</td>
                                            <td>75</td>
                                            <td>B-</td>
                                            <td>15th</td>
                                            <td class="remark">Good</td>
                                        </tr>
                                        </tr><tr><td class="res_sub">B.D.T</td>
                                            <td>7</td>
                                            <td>47</td>
                                            <td>54</td>
                                            <td>D</td>
                                            <td>22nd</td>
                                            <td class="remark">Poor</td>
                                        </tr>
                                        <tr><td class="res_sub">Creative Arts</td>
                                            <td>29</td>
                                            <td>68</td>
                                            <td>97</td>
                                            <td>A+</td>
                                            <td>1st</td>
                                            <td class="remark">Excellent</td>
                                        </tr>
                                    </tbody>
                                </table>

                                <div class="report_bottom">
                                    <p class="res_bot_resp">Order of Merit: <b>12th</b></p>
                                    <p class="res_bot_head">Class Teacher's Remark: </p>
                                    <p class="res_bot_resp">Very active and paticipative in class</p>
                                    <p class="res_bot_head">Head Teacher's Signature: </p>
                                    <p class="res_bot_resp">Signed: Mrs. Twin Vic</p>
                                </div>

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-info" name="sub_action" value="update_fee"><i class="fa fa-print myIcon2"></i> &nbsp; Print Result</button>
                                  </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>
        </div>
    </body>
</html>