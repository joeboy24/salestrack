<?php /* /Users/jbazz/Documents/Lara/PivoResults/resources/views/pages/dash/configuration.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item active2">
        <a class="nav-link" href="/config">
          <i class="fa fa-cogs"></i>
          <p>Configuration</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/addstudent">
          <i class="fa fa-group"></i>
          <p>Students</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="fa fa-edit"></i>
          <p>Registry</p>
        </a>
      <li class="nav-item ">
        <a class="nav-link" href="/fees">
          <i class="material-icons">content_paste</i>
          <p>Fees Mgt.</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-list"></i>
          <p>Attendance</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-table"></i>
          <p>Timetable</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">library_books</i>
          <p>Exam & Results</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-envelope"></i>
          <p>Messaging</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">bubble_chart</i>
          <p>Help</p>
        </a>
      </li>
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-7">

              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              

                

              

              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Configuration</h4>
                  <p class="card-category">Set up information about school here..</p>
                </div>
                <div class="card-body">
            
                  <div class="container">
                      <div class="row justify-content-center">
                          <div class="col-md-8">
                            <div class="card-header">Register</div>
                  
                              <div class="card-body">

                                <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>

                                  <div class="form-group">
                                    <!--label for="cat-title" class="col-form-label">Title:</label-->
                                    <input type="text" class="form-control" name="name" placeholder="School's Name" required/>
                                  </div>

                                  <div class="form-group">
                                    <textarea name="sch_add" class="form-control" rows="3" placeholder="Address" required></textarea>
                                  </div>

                                  <div class="form-group">
                                    <!--label for="cat-title" class="col-form-label">Title:</label-->
                                    <input type="text" class="form-control" name="loc" placeholder="Location"/>
                                  </div>
                                  
                                    
                      
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="contact" placeholder="Contact No." required/>
                                  </div>

                                  <div class="form-group">
                                    <input type="text" class="form-control" name="email" placeholder="Email" />
                                  </div>

                                  <div class="form-group">
                                    <input type="text" class="form-control" name="sch_web" placeholder="Website" />
                                  </div>
                                  
                                  <div class="">
                                    <label class="upfiles">Upload Logo: &nbsp; </label>
                                    <input type="file" name="sch_logo" required>
                                  </div>
                                  
                                  <?php if(count($company) > 0): ?>
                                    <div class="modal-footer">
                                      <p class="grants">Access Granted: School Details Already Set
                                    </div>
                                  <?php else: ?>
                                    <div class="modal-footer">
                                      <button type="submit" class="btn btn-info" name="store_action" value="admi_config"><i class="fa fa-save"></i> &nbsp; Save</button>
                                    </div>
                                  <?php endif; ?>
                                </form>

                              </div>
                                 
                            </div>
                              
                          </div>
                      </div>
                  </div>
              </div>

              <div class="card card-profile">
                <div class="card-body">
                  <h4 class="card-title">Define Academic Year & Term</h4>

                  <form action="<?php echo e(action('FeesController@update', 1)); ?>" method="POST">
                    <input type="hidden" name="_method" value="PUT">
                    <?php echo csrf_field(); ?>

                    
                    <div class="col-md-10 offset-md-1">

                      <label for="cat-title" class="col-form-label myLabel">Select Year/Term:</label>
                      <div class="form-group inputHold">

                        <select name="def" class="form-control inputLeft" id="def">
                          <option>Select</option>
                          <option value="ac_year">Year</option>
                          <option value="ac_term">Term</option>
                        </select>
          
                        <input type="text" class="form-control inputLeft" name="def_value" maxlength="4" placeholder="Type Term/Year Number eg. 1 or 2021 " required/>
                        <button type="submit" class="btn btn-info btnRight" name="sub_action" value="define_ac"  onclick="return confirm('Are you sure you want to update academic records?');"><i class="fa fa-save"></i> &nbsp; Save</button>
                      
                      </div>
                     
                    </div>

                  </form>
                   
                </div>
              </div>

                  <div style="height: 30px">
                  </div>

            </div>
 
            
            <div class="col-md-5">
              <div class="card card-profile">
                <div class="card-body">
                  <h4 class="card-title">Register Classes</h4>

                  <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    
                    <div class="col-md-10 offset-md-1">

                      <label for="cat-title" class="col-form-label myLabel">Class Name:</label>
                      <div class="form-group inputHold">
                        <input type="text" class="form-control inputLeft" name="cls_name" maxlength="10" placeholder="eg. Class 1 / Jhs 3B" required/>
                        <button type="submit" class="btn btn-info btnRight" name="store_action" value="config_create_class"><i class="fa fa-plus-circle"></i> &nbsp; Add</button>
                      </div>
                     
                    </div>

                  </form>
                   
                </div>
              </div>
            
                    <div style="height: 30px">
                    </div>

              <div class="card card-profile">
                <div class="card-body">
                  <h4 class="card-title">Additional Items To Buy/Pay</h4>

                  <div class="col-md-10 offset-md-1">
                  <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>



                    <label for="cat-title" class="col-form-label myLabel">Item Name:</label>
                    <div class="form-group">
                      <input type="text" class="form-control" name="name" placeholder="eg. School Fee, Boarding Fee,  Uniforms etc." required/>
                    </div>

                    <label for="cat-title" class="col-form-label myLabel">Description:</label>
                    
                    <div class="form-group">
                      <textarea name="desc" class="form-control" rows="3" placeholder="eg. PE/Sports Wear"></textarea>
                    </div>

                    <label for="cat-title" class="col-form-label myLabel">Cost: (GhC)</label>
                    <div class="form-group">
                      <input type="text" class="form-control" name="item_cost" maxlength="10" placeholder="eg. 1000"/>
                    </div>
                    
                    <div class="modal-footer">
                      <button type="submit" class="btn btn-info" name="store_action" value="create_payable"><i class="fa fa-save"></i> &nbsp; Save</button>
                    </div>
                  </form>
                  </div>
                   
                </div>
              </div>

                    <div style="height: 30px">
                    </div>

              <div class="card card-profile">
                <div class="card-body">
                  
                  <div class="form-group inputHold">
                    <button type="submit" class="btn btn-secondary" name="store_action" value="admi_upload_std" data-toggle="modal" data-target="#reg_classes"><i class="fa fa-folder-open"></i> &nbsp; View Registered Classes</button>
                    <button type="submit" class="btn btn-secondary" name="store_action" value="admi_upload_std" data-toggle="modal" data-target="#add_items"><i class="fa fa-folder-open"></i> &nbsp; View Additional Items</button>
                  </div>
                  
                </div>
              </div>
              
            </div>

          </div>
        </div>
  </div>


  <div class="modal fade" id="trsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Add Staff Here</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <!--label for="cat-title" class="col-form-label">Title:</label-->
              <input type="text" class="form-control" name="fname" placeholder="Firstname" required/>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="sname" placeholder="Other names" required/>
            </div>
            
            <label for="" class="col-form-label smalllable">Date of Birth: </label>
            <div class="form-group">
            <input type='date' class="form-control" placeholder="YYYY-MM-DD" name="dob" required/>
            </div>
            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Gender:</label>
              <select name="sex" class="form-control" id="sex">
                <option>Male</option>
                <option>Female</option>
              </select>
              <label for="recipient-name" class="col-form-label">Marital Status:</label>
              <select name="mstatus" class="form-control" id="mstatus">
                <option>Single</option>
                <option>Married</option>
                <option>Divorced</option>
                <option>Widow/er</option>
              </select>

              

            </div>

            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Role:</label>
              <select name="role" class="form-control" id="ROLE">
                <option>Teacher</option>
                <option>Other</option>
              </select>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="role_desc" placeholder="Role Description"/>
            </div>

            <div class="form-group">
              <input type="text" class="form-control" name="contact" placeholder="Contact No." required/>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="email" placeholder="Email" />
            </div>
            
            <div class="form-group">
              <input type="text" class="form-control" name="residence" placeholder="Place of Recidence"/>
            </div>

            <div class="">
              <label class="upfiles">Upload Photo: &nbsp; </label>
              <input type="file" name="tch_img" required>
            </div>
            
            <div class="modal-footer">
              <button type="submit" class="btn btn-info" name="store_action" value="admi_create_trs"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>

        </div>
        <!--div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Send message</button>
        </div-->
      </div>
    </div>
  </div>


  <div class="modal fade" id="clsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Confirm Class & Course Registeration</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <div class='col-md-10 offset-md-1'>
          <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            

            <div class="form-group">
             
              <label class="col-form-label">Choose Class</label>
              <select name="cls_name" class="form-control" id="cls_name">
                <option>Class 1</option>
                <option>Class 2</option>
                <option>Class 3A</option>
                <option>JHS 3</option>
              </select>
              
              <label class="col-form-label">Selected Subjects</label>
              <div class="form-group">
                <textarea name="sel_sub" id="txt_area" class="form-control myReadonly" placeholder="Course Description" rows="3" readonly></textarea>
              </div>

              <label class="col-form-label">Class Teacher/Lecturer</label>
              <select name="cls_tch" class="form-control" id="assign_tch">
                <option selected>Not Assigned</option>
                <option>Teacher 1</option>
                <option>Teacher 2</option>
                <option>Teacher 3</option>
              </select>

              

            </div>

            
      
            <div class="modal-footer">
              <button type="submit" class="btn btn-info" name="store_action" value="admi_create_cls"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>
          </div>

        </div>
        <!--div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Send message</button>
        </div-->
      </div>
    </div>
  </div>


  <div class="modal fade" id="reg_classes" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modtop" role="document">
      <div id="printarea" class="modal-content">
          <div class="card card-profile">
            <div class="card-avatar">
              <a href="#">
              
              </a>
            </div>
            <div class="card-body">
              <h6 class="card-category text-gray"></h6>
              <div style="height: 30px">
              </div>

              <?php if(count($company) > 0): ?>
                <h3 class="card-title"><?php echo e($results->name); ?></h3>
                <p class="card-category text-gray pp"><?php echo e($results->address); ?></p>
                <p class="card-category text-gray pp">Contact: <?php echo e($results->contact); ?></p>
                <p class="card-category text-gray pp">Email: <?php echo e($results->email); ?></p>
                <h4 class="card-title">Registered Classes</h4>
              <?php else: ?>
                <h3 class="card-title">School name not set</h3>
                <p class="card-category text-gray pp">school address not set</p>
                <p class="card-category text-gray pp">Contact: Not set / Email: Not set</p>
                <h4 class="card-title">Registered Classes</h4>
              <?php endif; ?>

              

              


              <?php if(count($stages) != 0): ?>

              <table id="config_tbl">
                <thead>
                  <th><h5 class="card-title">#</h5></th>
                  <th><h5 class="card-title">Class Name</h5></th>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <form action="<?php echo e(action('StudentController@destroy', $stage->id)); ?>" method="POST">

                      <input type="hidden" name="_method" value="DELETE">
                      <?php echo csrf_field(); ?>


                      <tr><td><?php echo e($r++); ?></td>
                        <td><?php echo e($stage->cls_name); ?>

                          <button type="submit" name="sub_action" value="cls_del" rel="tooltip" title="Delete Class" class="close2" onclick="return confirm('Are you sure you want to delete class?');"><i class="fa fa-close"></i></button>
                        </td>
                        </tr>

                    </form>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>

              <?php else: ?>
              <p>Oops..! No class registered yet!</p>
              <?php endif; ?>

            </div>
          </div>
      </div>

    </div>
  </div>


  <div class="modal fade" id="add_items" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modtop" role="document">
      <div id="printarea" class="modal-content">
          <div class="card card-profile">
            <div class="card-avatar">
              <a href="#">
              
              </a>
            </div>
            <div class="card-body">
              <h6 class="card-category text-gray"></h6>
              <div style="height: 30px">
              </div>

              <?php if(count($company) > 0): ?>
                <h3 class="card-title"><?php echo e($results->name); ?></h3>
                <p class="card-category text-gray pp"><?php echo e($results->address); ?></p>
                <p class="card-category text-gray pp">Contact: <?php echo e($results->contact); ?></p>
                <p class="card-category text-gray pp">Email: <?php echo e($results->email); ?></p>
                <h4 class="card-title">Additional Items</h4>
              <?php else: ?>
                <h3 class="card-title">School name not set</h3>
                <p class="card-category text-gray pp">school address not set</p>
                <p class="card-category text-gray pp">Contact: Not set / Email: Not set</p>
                <h4 class="card-title">Additional Items</h4>
              <?php endif; ?>

              


              <?php if(count($payables) != 0): ?>

              <table id="config_tbl">
                <thead>
                  <th><h5 class="card-title">#</h5></th>
                  <th><h5 class="card-title">Item Name</h5></th>
                  <th><h5 class="card-title">Cost (GhC)</h5></th>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $payables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <form action="<?php echo e(action('StudentController@destroy', $payable->id)); ?>" method="POST">

                      <input type="hidden" name="_method" value="DELETE">
                      <?php echo csrf_field(); ?>


                      <tr><td><?php echo e($p++); ?></td>
                        <td><?php echo e($payable->name); ?></td>
                        <td><?php echo e($payable->cost); ?>.00 
                          <button type="submit" name="sub_action" value="item_del" rel="tooltip" title="Delete Item" class="close2" onclick="return confirm('Are you sure you want to delete class?');"><i class="fa fa-close"></i></button>
                        </td>
                        </tr>

                    </form>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>

              <?php else: ?>
              <p>Oops..! No items added yet!</p>
              <?php endif; ?>

            </div>
          </div>
      </div>

    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>