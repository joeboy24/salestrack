<?php /* /Users/jbazz/Documents/Lara/PivoResults/resources/views/pages/dash/feereports.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/config">
          <i class="fa fa-cogs"></i>
          <p>Configuration</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/addstudent">
          <i class="fa fa-group"></i>
          <p>Students</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="fa fa-edit"></i>
          <p>Registry</p>
        </a>
      <li class="nav-item active2">
        <a class="nav-link" href="/fees">
          <i class="material-icons">content_paste</i>
          <p>Fees Mgt.</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-list"></i>
          <p>Attendance</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-table"></i>
          <p>Timetable</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">library_books</i>
          <p>Exam & Results</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-envelope"></i>
          <p>Messaging</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">bubble_chart</i>
          <p>Help</p>
        </a>
      </li>
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-11">

              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group row mb-0 hideMe">

                  <div class="col-md-5 offset-md-0 myTrim">
                      <div class="input-group no-border">
                        <input type="text" value="" class="form-control search_field" id="search" name="search" placeholder="Search Records...">
                        <button type="submit" class="btn btn-white btn-round my_bt">
                          <i class="material-icons">search</i>
                          <div class="ripple-container"></div>
                        </button>

                          <a href="/feereports" class="refresh_a"><button type="submit" name="store_action" value="refresh_val" class="btn btn-success btn-round" id="mb">
                            <i class="fa fa-refresh"></i>
                            <div class="ripple-container"></div>
                          </button></a>

                      </div>
                  </div>

                  <div class="col-md-7 offset-md-0 myTrim">
                    <a href="/fees"><button type="submit" class="btn btn-white pull-right" ><i class="fa fa-arrow-left"></i></button></a>
                  </div>

                </div>

              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">All Reports On Fees</h4>
                  
                </div>
                <div id="printarea1" class="card-body">
            
                    <?php if(count($feereports) > 0): ?>
                        <table class="table">
                          <thead class=" text-secondary hideMe">
                            <th></th>
                            <th>Fullame</th>
                            <th>Class</th>
                            <th>Term</th>
                            <th>Year</th>
                            <th>Amount (GhC)</th>
                            <th>Date & Time</th>
                          </thead>
                          <tbody id="tb">
                            <?php $__currentLoopData = $feereports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feereport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($c%2==0): ?>
                                <tr class="rowColour"><td><?php echo e($c++); ?></td>
                              <?php else: ?>
                                <tr><td><?php echo e($c++); ?></td>
                              <?php endif; ?>
                                  <td><?php echo e($feereport->std_fullname); ?></td>
                                  <td><?php echo e($feereport->class); ?></td>
                                  <td><?php echo e($feereport->term); ?></td>
                                  <td><?php echo e($feereport->year); ?></td>
                                  <td><?php echo e($feereport->amount); ?></td>
                                  <td><?php echo e($feereport->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                        <?php echo e($feereports->links()); ?>

                    <?php else: ?>
                      <p>No Records Found</p>
                    <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript">
  $('#search').on('keyup',function(){
      $value=$(this).val();
      $.ajax({
          type : 'get',
          url : '<?php echo e(URL::to('searchreports')); ?>',
          data:{'search':$value},
          success:function(data){
          $('#tb').html(data);
          }
      });
  })
</script>
<script type="text/javascript">
  $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>