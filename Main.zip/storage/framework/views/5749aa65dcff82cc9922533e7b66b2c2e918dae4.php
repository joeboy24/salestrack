<?php /* /Users/jbazz/Documents/Lara/RoyalJoyam/resources/views/pages/dash/sales.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i> 
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/config">
          <i class="fa fa-cogs"></i>
          <p>Configuration</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/dashuser">
          <i class="fa fa-edit"></i>
          <p>Registry</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/waybill">
          <i class="fa fa-group"></i>
          <p>Waybill</p>
        </a>
      </li>
      <li class="nav-item active2">
        <a class="nav-link" href="/sales">
          <i class="fa fa-euro"></i>
          <p>Sales</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/reporting">
          <i class="fa fa-table"></i>
          <p>Reports</p>
        </a>
      </li>
      <!--li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-table"></i>
          <p>Null</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">library_books</i>
          <p>Null</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-envelope"></i>
          <p>Messaging</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">bubble_chart</i>
          <p>Help</p>
        </a>
      </li-->
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-11">

              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group row mb-0 hideMe">
                    <div class="col-md-5 offset-md-0 myTrim">
                      <div class="input-group no-border">
                        

                        <form action="<?php echo e(action('FeesController@store')); ?>" method="POST">
                          <?php echo csrf_field(); ?>

                        
                        </form>

                      </div>
                    </div>
                </div>

                <div class="col-md-12 offset-md-0">

                    <div class="form-group row mb-0 searchRef">
                        <form class="salesForm" action="<?php echo e(action('ItemsController@store')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="dropdown">

                              <input type="text" class="sref" name="item_name" placeholder="Search Item...." id="mySearch" onkeyup="filterFunction()" required/>
                            
                              <?php if(count($items) > 0): ?>

                                <div id="myDropdown" class="dropdown_content" onselect="myFunction()">
                                  <button type="button" onclick="closeDropdown()" class="btn print_black"><i class="fa fa-times"></i></button>

                                  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a id="selItem<?php echo e($item->id); ?>" onclick="selFunction<?php echo e($item->id); ?>()">
                                      <table class="itemlist_tbl">
                                        <tbody>
                                          <tr>
                                            <td><img class="img" style="width: 30px" src="/storage/rjv_items/<?php echo e($item->thumb_img); ?>" /></td>
                                            <td><b><?php echo e($item->name); ?></b><br><?php echo e($item->desc); ?></td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </a>

                                    <input id="b1<?php echo e($item->id); ?>" type="hidden" value="<?php echo e($item->b1); ?>"/>
                                    <input id="b2<?php echo e($item->id); ?>" type="hidden" value="<?php echo e($item->b2); ?>"/>
                                    <input id="b3<?php echo e($item->id); ?>" type="hidden" value="<?php echo e($item->b3); ?>"/>

                                    <input id="q1<?php echo e($item->id); ?>" type="hidden" value="<?php echo e($item->q1); ?>"/>
                                    <input id="q2<?php echo e($item->id); ?>" type="hidden" value="<?php echo e($item->q2); ?>"/>
                                    <input id="q3<?php echo e($item->id); ?>" type="hidden" value="<?php echo e($item->q3); ?>"/>
                                    <script>
                                      
                                      function myFunction() {
                                        var drp = document.getElementById("myDropdown");
                                        drp.style.display = "none";
                                      }

                                      function closeDropdown() {
                                        document.getElementById('myDropdown').style.display = 'none';
                                      }
                                      
                                      function selFunction<?php echo e($item->id); ?>() {
                                        var avlQty = "'q" + "<?php echo e(auth()->user()->bv); ?>'"

                                        var selItem = document.getElementById("selItem<?php echo e($item->id); ?>");
                                        document.getElementById("mySearch").value = "<?php echo e($item->name); ?>";
                                        document.getElementById("myDropdown").style.display = "none";

                                        document.getElementById("item_id").value = "<?php echo e($item->id); ?>"
                                        document.getElementById("item_no").value = "<?php echo e($item->item_no); ?>"
                                        document.getElementById("name").value = "<?php echo e($item->name); ?>"
                                        document.getElementById("cost_price").value = "<?php echo e($item->price); ?>"
                                        document.getElementById("price").value = document.getElementById("b<?php echo e(auth()->user()->bv); ?><?php echo e($item->id); ?>").value;
                                        document.getElementById("amt").value = "GhC "+document.getElementById("b<?php echo e(auth()->user()->bv); ?><?php echo e($item->id); ?>").value;
                                        // document.getElementById("rem").innerHTML = document.getElementById("q<?php echo e(auth()->user()->bv); ?><?php echo e($item->id); ?>").value;
                                        document.getElementById("qty_avl").innerHTML = document.getElementById("q<?php echo e(auth()->user()->bv); ?><?php echo e($item->id); ?>").value;

                                        document.getElementById("brand").innerHTML = " <?php echo e($item->brand); ?>"
                                        document.getElementById("desc").innerHTML = " <?php echo e($item->desc); ?>"
                                        document.getElementById("mp").style.display = "block";
                                        document.getElementById("mp2").style.display = "block";
                                        document.getElementById("mp3").style.display = "block";
                                      }
                                      
                                      function filterFunction() {
                                      
                                        document.getElementById("myDropdown").style.display = "block";
                                        
                                        var input, filter, ul, li, a, i;
                                        input = document.getElementById("mySearch");
                                        filter = input.value.toUpperCase();
                                        div = document.getElementById("myDropdown");
                                        a = div.getElementsByTagName("a");
                                        for (i = 0; i < a.length; i++) {
                                          txtValue = a[i].textContent || a[i].innerText;
                                          if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                            a[i].style.display = "";
                                          } else {
                                            a[i].style.display = "none";
                                          }
                                        }
                                      }

                                    </script>
                                    
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                              <?php endif; ?>
                            
                              
                            <input id="item_id" name="item_id" type="hidden"/>
                            <input id="name" name="name" type="hidden"/>
                            <input id="price" name="price" type="hidden"/>
                            <input id="cost_price" name="cost_price" type="hidden"/>

                            <input class="sref" id="item_no" name="item_no" type="text" placeholder="Reference" readonly/>
                            <input class="sqty" type="number" name="qty" placeholder="Qty" value="1" min="1" />
                            <input class="sqty" type="text" id="amt" placeholder="GhC" readonly/>
                            <!--button type="button" id="rem" class="btn">Rem</button-->
                            <button type="submit" class="btn btn-primary" name="store_action" value="add_to_cart"><i class="fa fa-plus"></i> &nbsp; Add Item</button>
                            <a href="/mpt_cart"><button type="button" class="btn btn-info" name="store_action" value="empty_cart"><i class="fa fa-trash"></i> &nbsp; Empty Cart</button></a>
                            
                            
                        
                          </div>

                          <div id="item_info">
                            <p id="mp3">Qty Available: &nbsp;<b id="qty_avl" class="my_b2">C</b></p>
                            <p id="mp">Brand: <b id="brand" class="my_b">A</b></p>
                            <p id="mp2">Description: <b id="desc" class="my_b">B</b></p>
                          </div>

                        </form>
                    </div>

                </div>

              <div class="card">
                <div class="card-header-primary">
                  <h4 class="card-title">Cart</h4>
                  
                </div>
                <div id="printarea1" class="card-body">
            
                    
                      <?php if(count($carts) > 0): ?>
                        <table class="table mt">
                          <thead class=" text-secondary hideMe">
                            <th>#</th>
                            <th>Item No.</th>
                            <th>Name</th>
                            <th>Qty</th>
                            <th>Unit Price(GhC)</th>
                            <th class="totAmt">Total(Ghc)</th>
                            <th class="ryt">Actions</th>
                          </thead>
                          <tbody id="tb">

                              <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  
                                <?php if($i%2==0): ?>
                                  <tr class="rowColour"><td><?php echo e($i); ?></td>
                                <?php else: ?>
                                  <tr><td><?php echo e($i); ?></td>
                                <?php endif; ?>
                                  <td><?php echo e($cart->item_no); ?></td>
                                  <td><?php echo e($cart->name); ?></td>
                                  <td><?php echo e($cart->qty); ?></td>
                                  <td><?php echo e($cart->unit_price); ?></td>
                                  <td class="totAmt"><?php echo e($cart->tot); ?></td>
                                  <td class="ryt">
                                    
                                    <form action="<?php echo e(action('ItemsController@update', $cart->id)); ?>" method="POST">
                                      <input type="hidden" name="_method" value="PUT">
                                      <?php echo csrf_field(); ?>


                                      <a class="edit" rel="tooltip" title="Edit Record" data-toggle="modal" data-target="#changeModal_<?php echo e($cart->id); ?>"><i class="fa fa-pencil"></i></a>
                                      
                                      <button type="submit" name="store_action" value="del_cart" rel="tooltip" title="Delete Item" class="close2" onclick="return confirm('Are you sure you want to delete selected item?');"><i class="fa fa-close"></i></button>
                                    
                                    </form>  

                                      <div class="modal fade" id="changeModal_<?php echo e($cart->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                          <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-edit"></i>&nbsp;&nbsp; Edit Item Quantity</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                                </button>
                                              </div>
                                            <div class="modal-body myModalBody">
                                    
                                                <div class="row">
                                                            
                                                    <div class="col-sm-10 col-sm-offset-1">
                                                        <div class="login-form"><!--Item change form-->
                                                            <form action="<?php echo e(action('ItemsController@update', $cart->id)); ?>" method="POST">
                                                                <input type="hidden" name="_method" value="PUT">
                                                                <input type="hidden" name="my_url" value="/checkout1">
                                                                <?php echo csrf_field(); ?>
                                
                                                                <div class="cartIncrease">
                                                                    <input type="hidden" min="1" name="price" value="<?php echo e($cart->unit_price); ?>">
                                                                    <input type="number" min="1" name="change" value="<?php echo e($cart->qty); ?>">
                                                                    <button class="black_btn" type="submit" name="store_action" value="qty_change"><i class="fa fa-save"></i> &nbsp; SAVE</button>
                                                                </div>
                                                                  
                                                            </form>
                                                        </div><!--/Item change form-->
                                                    
                                                    </div>
                                                    
                                                </div>        
                                                
                                                
                                            </div>
                                    
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                
                                    
                                  </td>
                                </tr>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                              <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><b><?php echo e($carts->sum('qty')); ?></b></td>
                                <td></td>
                                <td class="totAmt"><b><?php echo e(number_format($carts->sum('tot'))); ?>.00</b></td>
                                <td class="ryt">      
                                </td>
                              </tr>
                              

                          </tbody>
                        </table>
                      <?php else: ?>
                        <p>Add items to start purchase</p>
                      <?php endif; ?>
                        

                        <div style="height: 30px">
                        </div>
      

                    
                </div>

                <div class="form-group row mb-0 searchRef2">
                  <form class="salesForm2" action="<?php echo e(action('ItemsController@store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <select name="pay_mode">
                      <option selected>-- Mode of Payment --</option>
                      <option>Cash</option>
                      <option>Cheque</option>
                      <option>Mobile Money</option>
                      <option>Post Payment(Debt)</option>
                    </select> 
                      <input type="text" class="sref2" name="buy_name" placeholder="Buyer's Name" required/>
                      <input type="number" class="sref2" name="buy_contact" placeholder="Contact" min="0" required/>
                    <select name="del_status">
                      <option selected>-- Delivery Status --</option>
                      <option>Delivered</option>
                      <option>Not Delivered</option>
                    </select> 
                      <?php if(count($carts) > 0): ?>
                        <button type="submit" class="btn btn-primary" name="store_action" value="add_to_sales"><i class="fa fa-money"></i> &nbsp; Pay Bill</button>
                      <?php endif; ?>
                      
                  </form>
                </div>

              </div>
              
              <form action="<?php echo e(url('/changedate')); ?>" method="GET">
                <div class="form-group row mb-0 searchRef">
                  <input class="sref" id="item_no" name="date_today" type="date" style="height: 37px; margin: 5px" placeholder="yyyy-mm-dd"/>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-calendar"></i> &nbsp; Change Today's Date</button>
                </div>
              </form>

              <div class="col-md-12 offset-md-0">
                <div class="card">
                  <div id="printarea1" class="card-body">
              
                    <?php if(count($sales) > 0): ?>
                        <table class="table mt">
                          <thead class=" text-secondary hideMe">
                            <th>#</th>
                            <th>Order No.</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Pay Mode</th>
                            <th>Buyer's Name</th>
                            <th>Contact</th>
                            <th>Status</th>
                            <th>Date/Time Created</th>
                            <th class="ryt">Actions</th>
                          </thead>
                          <tbody id="tb">

                            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <?php if($sale->del == 'no'): ?>
                                
                                <?php if($c%2==0): ?>
                                  <?php if($sale->del_status == 'Not Delivered'): ?>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid != 'Paid'): ?>
                                      <tr class="debt_alert">
                                    <?php else: ?>
                                    <tr class="not_delivered">
                                    <?php endif; ?>
                                  <?php else: ?>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid != 'Paid'): ?>
                                      <tr class="debt_alert">
                                    <?php else: ?>
                                      <tr class="rowColour">
                                    <?php endif; ?>
                                  <?php endif; ?>
                                <?php else: ?>
                                  <?php if($sale->del_status == 'Not Delivered'): ?>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid != 'Paid'): ?>
                                      <tr class="debt_alert">
                                    <?php else: ?>
                                    <tr class="not_delivered">
                                    <?php endif; ?>
                                  <?php else: ?>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid != 'Paid'): ?>
                                      <tr class="debt_alert">
                                    <?php else: ?>
                                      <tr>
                                    <?php endif; ?>
                                  <?php endif; ?>
                                <?php endif; ?>
                                  <td><?php echo e($c++); ?></td>
                                  <td><?php echo e($sale->order_no); ?></td>
                                  <td><?php echo e($sale->qty); ?></td>
                                  <?php if($sale->tot == $sale->paid_debt): ?>
                                    <td>GhC <?php echo e(number_format($sale->tot)); ?></td>
                                  <?php else: ?>
                                    <td>GhC <?php echo e(number_format($sale->tot - $sale->paid_debt)); ?></td>
                                  <?php endif; ?>
                                  <td><?php echo e($sale->pay_mode); ?><br>
                                    <?php if($sale->pay_mode == 'Post Payment(Debt)' && $sale->paid == 'Paid'): ?>
                                      <b><?php echo e($sale->paid); ?></b>
                                      &nbsp; <i class="fa fa-check" style="color: rgb(0, 163, 0)"></i>
                                    <?php endif; ?>
                                  </td>  
                                  <td><?php echo e($sale->buy_name); ?></td>
                                  <td><?php echo e($sale->buy_contact); ?></td>
                                  <form action="<?php echo e(url('/deliverer')); ?>" method="GET">
                                    <td><?php echo e($sale->del_status); ?>&nbsp;
                                    
                                    
                                      <?php echo csrf_field(); ?>
                                      <?php if($sale->del_status == 'Delivered'): ?>
                                        <input type="hidden" name="deliverer" value="<?php echo e($sale->id); ?>">
                                        <input type="hidden" name="deliverer_text" value="Not Delivered">
                                        <button type="submit" class="btn btn-success"><i class="fa fa-times"></i></button>
                                      <?php else: ?>
                                        <input type="hidden" name="deliverer" value="<?php echo e($sale->id); ?>">
                                        <input type="hidden" name="deliverer_text" value="Delivered">
                                        <button type="submit" class="btn btn-warning"><i class="fa fa-check"></i></button>
                                      <?php endif; ?>
                                    </td>
                                  </form>
                                  <td><?php echo e($sale->created_at); ?></td>  

                                  
                                    <td>
                                      <a href="/reporting/<?php echo e($sale->id); ?>"><button type="button" title="Print Order" class="print_black"><i class="fa fa-print"></i></button></a>
                                      
                                      <?php if($sale->pay_mode == 'Post Payment(Debt)'): ?>
                                        <button type="submit" data-toggle="modal" data-target="#pay_debt<?php echo e($sale->id); ?>" title="Pay Debt" class="print_black"><i class="fa fa-money"></i></button>
                                        <div class="modal fade" id="pay_debt<?php echo e($sale->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog modtop" role="document">
                                            <div id="printarea" class="modal-content">
                                              <div class="modal-header">
                                                <h6 class="modal-title" id="exampleModalLabel"><i class="fa fa-save"></i>&nbsp;&nbsp; Make Payment for <?php echo e($sale->buy_name); ?></h6>
                                                
                                                  
                                                </button>
                                              </div>
                                                <div class="card card-profile">
                                                  <div class="card-avatar">
                                                    <a href="#">
                                                    
                                                    </a>
                                                  </div>
                                                  <div class="card-body">
                                                    <h6 class="card-category text-gray"></h6>
                                                    <div style="height: 30px">
                                                    </div>
                                      
                                                    <form action="<?php echo e(action('ItemsController@store')); ?>" method="POST">
                                                      <?php echo csrf_field(); ?>
                      
                                                      <div class="cartIncrease">
                                                        <input type="hidden" name="send_id" value="<?php echo e($sale->id); ?>">
                                                        <input type="hidden" name="send_tot" value="<?php echo e($sale->tot); ?>">
                                                        <input type="number" min="1" name="amt_paid" placeholder="Amount" value="<?php echo e($sale->tot - $sale->paid_debt); ?>" max="<?php echo e($sale->tot - $sale->paid_debt); ?>">
                                                        <button class="black_btn" type="submit" name="store_action" value="pay_debt" onclick="return confirm('Are you sure you want to proceed payment?');"><i class="fa fa-money"></i> &nbsp; Pay</button>
                                                      </div>
                                                        
                                                    </form>
                                      
                                                  </div>
                                                </div>
                                            </div>
                                      
                                          </div>
                                        </div>
                                      <?php endif; ?>
                                    </td> 
                                  

                                </tr>

                                <?php if($sale->del_status == 'Not Delivered' && $sale->pay_mode == 'Post Payment(Debt)'): ?>
                                
                                  <tr id="showTR2">
                                    <td></td>
                                    <td><b>Items Delivery Status</b></td>
                                    <td></td>
                                    <td></td>
                                    <td><b>Item No.</b></td>
                                    <td><b>Name</b></td>
                                    <td>Qty.</td>
                                    <td><b>Status</b></td>
                                    <td><b>Date</b></td>
                                    <td><b>Action</b></td>  
                                  </tr>
                                  <?php $__currentLoopData = $sale->saleshistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td><?php echo e($sh->item_no); ?></td>
                                      <td><?php echo e($sh->name); ?></td>
                                      <td><?php echo e($sh->qty); ?></td>
                                      <td><?php echo e($sh->del_status); ?></td>
                                      <td><?php echo e($sh->created_at); ?></td>
                                      <form action="<?php echo e(action('ItemsController@update', $sh->id)); ?>" method="POST">
                                        <input type="hidden" name="_method" value="PUT">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="send_sale_id" value="<?php echo e($sale->id); ?>">
                                        <?php if($sh->del_status == 'Delivered'): ?>
                                          <td><button class="btn btn-info" name="store_action" value="undeliver"><i class="fa fa-suitcase"></i> &nbsp; Undeliver</button></td>  
                                        <?php else: ?>
                                          <td><button class="btn btn-warning" name="store_action" value="deliver"><i class="fa fa-suitcase"></i> &nbsp; Deliver Now</button></td>  
                                        <?php endif; ?>
                                        </form>
                                    </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    
                                <?php endif; ?>
                              
                              <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </tbody>
                        </table>
                        <p>Sales Count : <b style="color: #000000"><?php echo e(count($sales)); ?></b></p>
                        <?php echo e($sales->links()); ?>


                        <div style="height: 30px">
                        </div>
      

                    <?php else: ?>
                      <p>No Records Found</p>
                    <?php endif; ?>
                  </div>
                </div>
              </div>

              <div class="container-fluid hideMe">

                <div class="row">
      
                  <div class="col-lg-3 col-md-6 col-sm-6">
                    <a data-toggle="modal" data-target="#totbreakdownModal" class="myA">
                      <div class="card card-stats">
                        <button class="btn salesBtn purple"><i class="fa fa-folder-open salesI"></i></button>
                        <h4 class='config2'>GhC <?php echo e(number_format($sum_inc_dbt)); ?>.00</h4>
                        
                        <div class="card-footer">
                          <div class="stats">Total Sales <?php echo e(date('d/m/Y')); ?></div>
                        </div>
                      </div>
                    </a>
                  </div>
      
                  <div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="/expenses" class="myA">
                      <div class="card card-stats">
                        <button class="btn salesBtn pink"><i class="fa fa-money salesI"></i></button>
                        <h4 class='config2'>GhC <?php echo e(number_format($expenses->sum('expense_cost'))); ?>.00</h4>
                        
                        <div class="card-footer">
                          <div class="stats">Daily Expenditure Report</div>
                        </div>
                      </div>
                    </a>
                  </div>

                  <div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="#" class="myA">
                      <div class="card card-stats">
                        <button class="btn salesBtn mygreen"><i class="fa fa-dollar salesI"></i></button>
                        <h4 class='config2'>GhC <?php echo e(number_format($debts_paid)); ?>.00</h4>
                        
                        <div class="card-footer">
                          <div class="stats">Paid Debts</div>
                        </div>
                      </div>
                    </a>
                  </div>
      
                  <!--div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="#" class="myA">
                      <div class="card card-stats">
                        <button class="btn salesBtn seablue"><i class="fa fa-euro salesI"></i></button>
                        <h4 class='config2'>GhC Null</h4>
                        
                        <div class="card-footer">
                          <div class="stats">Daily Null Report</div>
                        </div>
                      </div>
                    </a>
                  </div-->
      
                </div>

              </div>

            </div>


          </div>
        </div>
  </div>



  <div class="modal fade" id="totbreakdownModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Total Amount(GhC) Breakdown</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <table class="breakdown">
            <tr><td class="tt">Cash</td><td><b class="pr">GhC <?php echo e(number_format($cash)); ?></b>.00</td></tr>
            <tr><td class="tt">Cheque</td><td><b class="pr">GhC <?php echo e(number_format($cheque)); ?></b>.00</td></tr>
            <tr><td class="tt">Mobile Money</td><td><b class="pr">GhC <?php echo e(number_format($momo)); ?></b>.00</td></tr>
            <tr><td class="tt">Post Payment(Debt)</td><td><b class="pr">GhC <?php echo e(number_format($sum_dbt)); ?></b>.00</td></tr>
          </table>

        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="orderModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Record Order Details Here</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          
            <form action="<?php echo e(action('ItemsController@store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <div class="col-md-12">
                        <input id="" placeholder="Reference No/Id" type="text" class="form-control" name="ref" required autofocus>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-12">
                        <input id="company_name" placeholder="From: Company Name" type="text" class="form-control" name="company_name" required autofocus>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-12">
                        <input id="contact" placeholder="From: Company's Contact" type="text" class="form-control" name="contact" required autofocus>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-12">
                    <textarea name="desc" class="form-control" rows="3" placeholder="Description"></textarea>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-12">
                        <input id="tot" placeholder="Total Amt. GhC" type="number" class="form-control" name="tot" required autofocus>
                    </div>
                </div>

                <div class="col-md-12">
                    <label class="upfiles">Upload Receipt: &nbsp; </label>
                    <input type="file" name="repfile" required>
                </div>

                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-info" name="store_action" value="add_order"><i class="fa fa-save"></i> &nbsp; Submit</button>
                    </div>
                </div>
            </form>

        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript">
  $('#search').on('keyup',function(){
      $value=$(this).val();
      $.ajax({
          type : 'get',
          url : '<?php echo e(URL::to('/searchfee')); ?>',
          data:{'search':$value},
          success:function(data){
          $('#tb').html(data);
          }
      });
  })
</script>
<script type="text/javascript">
  $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });

  function showsubdet() {
    document.getElementById('showTR').style.display = 'block';
  }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>