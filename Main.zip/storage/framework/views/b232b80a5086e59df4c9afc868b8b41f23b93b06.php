<?php /* /Users/jbazz/Documents/Lara/RoyalJoyam/resources/views/pages/dash/waybillview.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i> 
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/config">
          <i class="fa fa-cogs"></i>
          <p>Configuration</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/dashuser">
          <i class="fa fa-edit"></i>
          <p>Registry</p>
        </a>
      </li>
      <li class="nav-item active2">
        <a class="nav-link" href="/waybill">
          <i class="fa fa-group"></i>
          <p>Waybill</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/sales">
          <i class="fa fa-euro"></i>
          <p>Sales</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/reporting">
          <i class="fa fa-table"></i>
          <p>Reports</p>
        </a>
      </li>
      <!--li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-table"></i>
          <p>Null</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">library_books</i>
          <p>Null</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-envelope"></i>
          <p>Messaging</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">bubble_chart</i>
          <p>Help</p>
        </a>
      </li-->
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-11">

              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group row mb-0 hideMe">

                  <div class="col-md-5 offset-md-0 myTrim">

                    <form style="width: 400px" method="GET" action="<?php echo e(url('/waybillview')); ?>">
                      <div class="input-group no-border">
                        

                          <input type="search" value="" class="form-control search_field" id="waybillsearch" name="waybillsearch" placeholder="Search Waybill...">
                          
                          <button type="submit" class="btn btn-white btn-round my_bt">
                            <i class="material-icons">search</i>
                            <div class="ripple-container"></div>
                          </button>

                          <a href="/waybillview" class="refresh_a"><button type="submit" class="btn btn-success btn-round" id="mb">
                            <i class="fa fa-refresh"></i>
                            <div class="ripple-container"></div>
                          </button></a>
                          
                      </div>
                    </form>
                      
                  </div>
                  <div class="col-md-7 offset-md-0 myTrim">
                    <a href="#"><button type="submit" class="btn btn-white pull-right" title="Recycle Bin"><i class="fa fa-trash"></i></button></a>
                    <a href="/waybill"><button type="submit" class="btn btn-white pull-right" ><i class="fa fa-arrow-left"></i></button></a>
                    
                  </div>

                </div>

              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">All Bills</h4>
                  
                </div>
                <div id="printarea1" class="card-body">
            
                    <?php if(count($waybills) > 0): ?>
                        <table class="table mt">
                          <thead class=" text-secondary hideMe">
                            <th>#</th>
                            <th>Company/From</th>
                            <th>Adress</th>
                            <th>Cmp. Contact</th>
                            <th>Dispatch Driver</th>
                            <th>Drv. Contact</th>
                            <th>Vehicle Reg.No.</th>
                            <th>Waybill No.</th>
                            <th>Weight</th>
                            <th>No. of Pieces</th>
                            <th>Tot. Qty</th>
                            <th>Delivery Date</th>
                            <th>Stock No.</th>
                            <th>Status</th>
                            <th class="ryt">Actions</th>
                          </thead>
                          <tbody id="tb">

                            <?php $__currentLoopData = $waybills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $waybill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <?php if($waybill->del == 'no'): ?>
                                
                                <?php if($c%2==0): ?>
                                  <tr class="rowColour"><td><?php echo e($c++); ?></td>
                                <?php else: ?>
                                  <tr><td><?php echo e($c++); ?></td>
                                <?php endif; ?>
                                  <td><?php echo e($waybill->comp_name); ?></td>
                                  <td><?php echo e($waybill->comp_add); ?></td>
                                  <td><?php echo e($waybill->comp_contact); ?></td>
                                  <td><?php echo e($waybill->drv_name); ?></td>
                                  <td><?php echo e($waybill->drv_contact); ?></td>
                                  <td><?php echo e($waybill->vno); ?></td>
                                  <td><?php echo e($waybill->bill_no); ?></td>
                                  <td><?php echo e($waybill->weight); ?></td>
                                  <td><?php echo e($waybill->nop); ?></td>
                                  <td><?php echo e($waybill->tot_qty); ?></td>
                                  <td><?php echo e($waybill->del_date); ?></td>
                                  <td><?php echo e($waybill->stock_no); ?></td>
                                  <td><?php echo e($waybill->status); ?></td>
                                  <td class="ryt">
                                    
                                    <form action="<?php echo e(action('ItemsController@update', $waybill->id)); ?>" method="POST">
                                      <input type="hidden" name="_method" value="PUT">
                                      <?php echo csrf_field(); ?>

                                      <a href="" class="edit" data-toggle="modal" rel="tooltip" title="Edit Record" data-target="#edit_<?php echo e($waybill->id); ?>"><i class="fa fa-pencil"></i></a>
                                      
                                      <button type="submit" name="store_action" value="del_item" rel="tooltip" title="Delete Item" class="close2" onclick="return confirm('Are you sure you want to delete record?');"><i class="fa fa-close"></i></button>
                                    

                                      <div class="modal fade" id="edit_<?php echo e($waybill->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modtop" role="document">
                                          <div class="modal-content">
                                              
                                              <div class="card card-profile">
                                                <div class="card-body">
                                                  
                                                  <div class="row justify-content-center">

                                                      <div class="col-md-6 cl">
                                                        <div style="height:30px"></div>
                                                        
                                                        <p>Sender Info. / From:</p>
                                                        <div class="my_panel">
                                                          <div class="input_div">
                                                              <p>Company Name: </p>
                                                              <input type="text" name="comp_name" value="<?php echo e($waybill->comp_name); ?>" required/>
                                                          </div>
                              
                                                          <div class="input_div">
                                                              <p>Address: </p>
                                                              <textarea name="comp_add" rows="4" required><?php echo e($waybill->comp_add); ?></textarea>
                                                          </div>
                              
                                                          <div class="input_div">
                                                              <p>Contact: </p>
                                                              <input type="text" name="comp_contact" value="<?php echo e($waybill->comp_contact); ?>" required/>
                                                          </div>
                                                        </div>
                              
                                                        <p>Dispatch Driver</p>
                                                        <div class="my_panel">
                                                          <div class="input_div">
                                                              <p>Driver's Name: </p>
                                                              <input type="text" name="drv_name" value="<?php echo e($waybill->drv_name); ?>" required/>
                                                          </div>
                              
                                                          <div class="input_div">
                                                              <p>Contact: </p>
                                                              <input type="text" name="drv_contact" value="<?php echo e($waybill->drv_contact); ?>" required/>
                                                          </div>
                              
                                                          <div class="input_div">
                                                              <p>Vehicle Reg. No: </p>
                                                              <input type="text" name="vno" value="<?php echo e($waybill->vno); ?>" required/>
                                                          </div>
                                                        </div>   
                              
                                                      </div>
                                                
                                                      <div class="col-md-6">
                                                        <div style="height:60px"></div>
                              
                                                        <div class="input_div">
                                                            <p>Waybill No.: </p>
                                                            <input type="text" min="0" name="bill_no" value="<?php echo e($waybill->bill_no); ?>" required/>
                                                        </div>
                              
                                                        <div class="input_div">
                                                            <p>Weight of Package: </p>
                                                            <input type="text" name="weight" value="<?php echo e($waybill->weight); ?>"/>
                                                        </div>
                              
                                                        <div class="input_div">
                                                            <p>No. of Pieces: </p>
                                                            <input type="text" name="nop" value="<?php echo e($waybill->nop); ?>"/>
                                                        </div>
                              
                                                        <div class="input_div">
                                                            <p>Total Quantity: </p>
                                                            <input type="text" name="tot_qty" value="<?php echo e($waybill->tot_qty); ?>"/>
                                                        </div>
                              
                                                        <div class="input_div">
                                                            <p>Delivery Date: </p>
                                                            <input type="date" placeholder="DD/MM/YYY" name="del_date" value="<?php echo e($waybill->del_date); ?>"/>
                                                        </div>
                              
                                                        <div class="input_div">
                                                          <p>Status: </p>
                                                          <select name="status">
                                                            <option selected><?php echo e($waybill->status); ?></option>
                                                            <option>Pending</option>
                                                            <option>Delivered</option>
                                                          </select>
                                                        </div>
                                                      
                                                      </div>
                                              
                              
                                                    </div>                 

                                                </div>
                                              </div>
                                              
                                              <div class="modal-footer">
                                                <button type="submit" class="btn btn-info" name="store_action" value="update_waybill"><i class="fa fa-save"></i> &nbsp; Update Record</button>
                                              </div>

                                          </div>
                                    
                                        </div>
                                      </div>

                                    </form>                  
                                    
                                  </td>
                                </tr>
                              
                              <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </tbody>
                        </table>
                        <p>Total: <b style="color: #000000"><?php echo e(count($waybills)); ?></b></p>

                        

                         <?php echo e($waybills->appends(['waybillsearch' => request()->query('waybillsearch')])->links()); ?>


                        <div style="height: 30px">
                        </div>
      

                    <?php else: ?>
                      <p>No Records Found</p>
                    <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>

  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>