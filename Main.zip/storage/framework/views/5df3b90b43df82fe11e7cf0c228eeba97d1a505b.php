<?php /* /Users/jbazz/Documents/Lara/RoyalJoyam/resources/views/pages/dash/itemsview.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i> 
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/config">
          <i class="fa fa-cogs"></i>
          <p>Configuration</p>
        </a>
      </li>
      <li class="nav-item active2">
        <a class="nav-link" href="/dashuser">
          <i class="fa fa-edit"></i>
          <p>Registry</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/waybill">
          <i class="fa fa-group"></i>
          <p>Waybill</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/sales">
          <i class="fa fa-euro"></i>
          <p>Sales</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/reporting">
          <i class="fa fa-table"></i>
          <p>Reports</p>
        </a>
      </li>
      <!--li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-table"></i>
          <p>Null</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">library_books</i>
          <p>Null</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="fa fa-envelope"></i>
          <p>Messaging</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="#">
          <i class="material-icons">bubble_chart</i>
          <p>Help</p>
        </a>
      </li-->
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-11">

              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group row mb-0 hideMe">

                  <div class="col-md-5 offset-md-0 myTrim">

                    <form style="width: 400px" method="GET" action="<?php echo e(url('/items')); ?>">
                      <?php echo csrf_field(); ?>
                      <div class="input-group no-border">
                        

                          <input type="search" value="" class="form-control search_field" id="itemsearch" name="itemsearch" placeholder="Search Records...">
                           
                          <button type="submit" class="btn btn-white btn-round my_bt">
                            <i class="material-icons">search</i>
                            <div class="ripple-container"></div>
                          </button>

                          <a href="/items" class="refresh_a"><button type="submit" class="btn btn-success btn-round" id="mb">
                            <i class="fa fa-refresh"></i>
                            <div class="ripple-container"></div>
                          </button></a>
                          
                      </div>
                    </form>
                      
                  </div>
                  <div class="col-md-7 offset-md-0 myTrim">
                    <a href="#"><button type="submit" class="btn btn-white pull-right" title="Recycle Bin"><i class="fa fa-trash"></i></button></a>
                    <a href="/dashuser"><button type="submit" class="btn btn-white pull-right" ><i class="fa fa-arrow-left"></i></button></a>
                    
                  </div>

                </div>

              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Stock View</h4>
                  
                </div>
                <div id="printarea1" class="card-body">
            
                    <?php if(count($items) > 0): ?>
                        <table class="table mt">
                          <thead class=" text-secondary hideMe">
                            <th>#</th>
                            <th>Item No.</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Category</th>
                            <th>Barcode</th>
                            <th>Qty</th>
                            <th>Price(GhC)</th>
                            <th>Thumbnail</th>
                            <th>Date Created</th>
                            <th class="ryt">Actions</th>
                          </thead>
                          <tbody id="tb">

                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <?php if($item->del == 'no'): ?>
                                
                                <?php if($c%2==0): ?>
                                  <tr class="rowColour"><td><?php echo e($c++); ?></td>
                                <?php else: ?>
                                  <tr><td><?php echo e($c++); ?></td>
                                <?php endif; ?>
                                  <td><?php echo e($item->item_no); ?></td>
                                  <td><?php echo e($item->name); ?></td>
                                  <td><?php echo e($item->desc); ?></td>
                                  <td><?php echo e($item->cat); ?></td>
                                  <td><?php echo e($item->barcode); ?></td>
                                  <td><?php echo e($item->qty); ?></td>
                                  <td><?php echo e($item->price); ?></td>
                                  <td><?php echo e($item->thumb_img); ?></td>
                                  <td><?php echo e($item->created_at); ?></td>
                                  <td class="ryt">
                                    
                                    <form action="<?php echo e(action('ItemsController@update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                                      <input type="hidden" name="_method" value="PUT">
                                      <?php echo csrf_field(); ?>


                                      <a href="" class="edit" data-toggle="modal" rel="tooltip" title="Edit Record" data-target="#edit_<?php echo e($item->id); ?>"><i class="fa fa-pencil"></i></a>
                                      
                                      <button type="submit" name="store_action" value="del_item" rel="tooltip" title="Delete Item" class="close2" onclick="return confirm('Are you sure you want to delete selected item?');"><i class="fa fa-close"></i></button>
                                    

                                      <div class="modal fade" id="edit_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modtop" role="document">
                                          <div class="modal-content">
                                              
                                              <div class="card card-profile">
                                                <div class="card-avatar">
                                                  <a href="#pablo">
                                                  <img class="img" src="/storage/rjv_items/<?php echo e($item->thumb_img); ?>" />
                                                  </a>
                                                </div>
                                                <div class="card-body">
                                                  <h4 class="card-category text-gray">Item N0: <?php echo e($item->item_no); ?></h4>
                                                  <h6 class="card-title">Created by: <?php echo e($item->user_id); ?></h6>




                                                  <table class="user_view_tbl">
                                                    <tbody>

                                                      <tr class="tbl_tr"><td class="tl">Item Name</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="text" class="form-control" name="name" placeholder="Item Name" value="<?php echo e($item->name); ?>" required/>
                                                        </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Description</td><td class="tr">
                                                        <div class="form-group">
                                                          <textarea type="text" class="form-control" rows="4" name="desc" placeholder="Description" required><?php echo e($item->desc); ?></textarea>
                                                        </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Category</td><td class="tr">
                                                        <div class="form-group">
                                                          <select name="cat" class="form-control" id="cat">
                                                            <option selected><?php echo e($item->cat); ?></option>
                                                            <?php if(count($cats) > 0): ?>
                                                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <?php if($cat->del != 'yes'): ?>
                                                                <option><?php echo e($cat->name); ?></option>
                                                              <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                          <?php endif; ?>
                                                          </select>
                                                        </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Brand</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="text" class="form-control" name="brand" placeholder="Brand" value="<?php echo e($item->brand); ?>" required/>
                                                        </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Barcode</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type='text' class="form-control" placeholder="Barcode" name="barcode" value="<?php echo e($item->barcode); ?>"/>
                                                        </div>
                                                      </td></tr>

                                                      <tr class="tbl_tr"><td class="tl">Quantity</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="number" class="form-control" name="qty" placeholder="Quantity" value="<?php echo e($item->qty); ?>" required/>
                                                        </div>
                                                      </td></tr>


                                                      <tr class="tbl_tr"><td class="tl">Cost Price</td><td class="tr">
                                                        <div class="form-group">
                                                          <input type="text" class="form-control" name="price" placeholder="Price" value="<?php echo e($item->price); ?>" required/>
                                                        </div>
                                                      </td></tr>


                                                      
                                                      
                                                      
                                                      

                                                        

                                                    </tbody>
                                                  </table>


                                                                   

                                                </div>
                                              </div>
                                              
                                              <div class="modal-footer">
                                                <button type="submit" class="btn btn-info" name="store_action" value="update_item"><i class="fa fa-save"></i> &nbsp; Update Record</button>
                                              </div>

                                          </div>
                                    
                                        </div>
                                      </div>

                                    </form>                  
                                    
                                  </td>
                                </tr>
                              
                              <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </tbody>
                        </table>
                        <p>Total : <b style="color: #000000"><?php echo e(count($items)); ?></b></p>

                        

                         <?php echo e($items->appends(['itemsearch' => request()->query('itemsearch')])->links()); ?> 

                        <div style="height: 30px">
                        </div>
      

                    <?php else: ?>
                      <p>No Records Found</p>
                    <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>

  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript">
  $('#search').on('keyup',function(){
      $value=$(this).val();
      $.ajax({
          type : 'get',
          url : '<?php echo e(URL::to('searchstudent')); ?>',
          data:{'search':$value},
          success:function(data){
          $('#tb').html(data);
          }
      });
  })
</script>
<script type="text/javascript">
  $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>