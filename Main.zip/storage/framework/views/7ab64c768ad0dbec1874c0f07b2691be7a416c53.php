<?php /* /Users/klasique/lara53/resources/views/pages/dash/galleryview.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item  ">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="material-icons">person</i>
          <p>Users</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/members">
          <i class="fa fa-users"></i>
          <p>Members</p>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="/galleryview">
          <i class="material-icons">image</i>
          <p>Gallery</p>
        </a>
      <li class="nav-item ">
        <a class="nav-link" href="/posts">
          <i class="material-icons">library_books</i>
          <p>Posts</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/tithes">
          <i class="material-icons">content_paste</i>
          <p>Tithe</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./icons.html">
          <i class="material-icons">bubble_chart</i>
          <p>Icons</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./map.html">
          <i class="material-icons">location_ons</i>
          <p>Maps</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./notifications.html">
          <i class="material-icons">notifications</i>
          <p>Notifications</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./rtl.html">
          <i class="material-icons">language</i>
          <p>RTL Support</p>
        </a>
      </li>
      <li class="nav-item active-pro ">
        <a class="nav-link" href="./upgrade.html">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">     

      <div class="row">
        <div class="col-md-12">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">GALLERY</h4>
              <p class="card-category"> Here is a list of all images & actions</p>
            </div>
            <div class="card-body">
              <button type="submit" class="btn btn-primary pull-right" data-toggle="modal" data-target="#imgModal"><i class="fa fa-plus"></i>&nbsp;&nbsp; Add Image</button>
              <button type="submit" class="btn btn-success pull-right" data-toggle="modal" data-target="#catgModal"><i class="fa fa-sitemap"></i>&nbsp;&nbsp; Add Catg</button>
              <div class="table-responsive">


                <?php if(count($gallery) > 0): ?>
                <table class="table">
                  <thead class=" text-primary">
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Date</th>
                    <th class="ryt">
                      Actions
                    </th>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($image->del != 'yes'): ?>
                            <tr>
                              <td><?php echo e($image->id); ?></td>
                              <td><?php echo e($image->img_name); ?></td>
                              <td><?php echo e($image->img_cat); ?></td>
                              <td><?php echo e(date('M-d-Y', strtotime($image->created_at))); ?> at <?php echo e(date('H:i', strtotime($image->created_at))); ?></td>
                              <td class="ryt">
                    
                                <form action="<?php echo e(action('PostsController@update', $image->id)); ?>" method="POST" class="float-right">
                                  <input type="hidden" name="_method" value="PUT">
                                  <?php echo csrf_field(); ?>

                                  <button type="submit" name="sub_action" value="gal_img_del" class="close2" title="Open" onclick="return confirm('Are you sure you want to delete this image?');"><i class="fa fa-close"></i></button>
                                  <button type="button" class="view2" title="View" data-toggle="modal" data-target="<?php echo e('#hold'.$image->id); ?>"><i class="fa fa-folder-open"></i></button>
                                  <!--textarea class="form-control" id="article-ckeditor" name="body" placeholder="Body/Text" rows="5"></textarea-->
                                </form>


                              <div class="modal fade" id="<?php echo e('hold'.$image->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <!--div class="modal-header">
                                          <h2 class="modal-title" id="exampleModalLabel"><i class="fa fa-dot-circle-o"></i>&nbsp;&nbsp; $post->title}}</h2>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                      </div-->
                                      <div class="modal-body">
                                        <div><img class="mm_img" src="../storage/gallery_imgs/<?php echo e($image->img_name); ?>"></div>
                                        
                                      </div>
                                      <!--div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary">Send message</button>
                                      </div-->
                                    </div>
                                  </div>
                                </div>


                              </td>
                            </tr>
                        <div class="paginationx"><?php echo e($gallery->links()); ?></div>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <p>No Image found</p>
                    <?php endif; ?>
                  </tbody>
                </table>

              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>


  <div class="modal fade" id="catgModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Add Image Category Here</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(action('PostsController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <input type="text" class="form-control" id="cat-title" name="cat_name" placeholder="Category Title">
            </div>
            <div class="form-group">
              <textarea class="form-control" id="message-text" name="cat_desc" maxlength="100" placeholder="Category Description"></textarea>
            </div>

            <div class="">
              <label class="upfiles">Cover Image: &nbsp; </label>
              <input type="file" name="catg_img" required>
            </div>
            
            <div class="modal-footer">
              <button type="submit" class="btn btn-success" name="store_action" value="sub_gal_cat"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>
        </div>
        <!--div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Send message</button>
        </div-->
      </div>
    </div>
  </div>
  
  <div class="modal fade" id="imgModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Add Images Here</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form action="<?php echo e(action('PostsController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>


            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Choose Image Category:</label>
              <select name="img_cat" class="form-control" id="cat">
              <?php $__currentLoopData = $gcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option><?php echo e($gcat->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="">
              <label class="upfiles">Image(s): &nbsp; </label>
              <input type="file" name="files[]" multiple required>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary" name="store_action" value="save_gal_img"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>