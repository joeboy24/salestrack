<?php /* /Users/klasique/lara53/resources/views/posts/edit.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item  ">
        <a class="nav-link" href="./dashboard.html">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="material-icons">person</i>
          <p>User Profile</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/galleryview">
          <i class="material-icons">image</i>
          <p>Gallery</p>
        </a>
      <li class="nav-item active ">
        <a class="nav-link" href="/posts">
          <i class="material-icons">library_books</i>
          <p>Posts</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./typography.html">
          <i class="material-icons">content_paste</i>
          <p>Typography</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./icons.html">
          <i class="material-icons">bubble_chart</i>
          <p>Icons</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./map.html">
          <i class="material-icons">location_ons</i>
          <p>Maps</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./notifications.html">
          <i class="material-icons">notifications</i>
          <p>Notifications</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./rtl.html">
          <i class="material-icons">language</i>
          <p>RTL Support</p>
        </a>
      </li>
      <li class="nav-item active-pro ">
        <a class="nav-link" href="./upgrade.html">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">     

      <div class="row">
        <div class="col-md-12">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-header card-header-primary">
                    <h2 class="card-title ">EDIT POST</h2>
                    <p class="card-category"> Use this panel to edit post</p>
                </div>
                <div class="card-body">
                    
                            <div class="col-xl-8 offset-xl-2">
                                
                                <form action="<?php echo e(action('PostsController@update', $post->id)); ?>" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="_method" value="PUT">
                    
                                    <?php echo csrf_field(); ?>

                                    <label>Title</label>
                                    <input type="text" value="<?php echo e($post->title); ?>" class="form-control" name="title" required/>
                                    <label>Body</label>
                                    <textarea class="form-control" id="article-ckeditor" name="body" rows="5" required><?php echo e($post->body); ?></textarea>
                                    <br>
                                    
                                    <div class="form-group">
                                        <label for="recipient-name" class="col-form-label">Choose Image Category:</label>
                                        <select name="cat" class="form-control" id="cat">
                                        <?php $__currentLoopData = $pcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($pcat->name == $post->post_cat): ?>
                                              <option selected><?php echo e($pcat->name); ?></option>
                                            <?php else: ?>
                                              <option><?php echo e($pcat->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
            
                                    <input type="file" class="upfiles" name="cover_img" value="<?php echo e($post->cover_img); ?>"><br>
                                    <input type="text" class="form-control" name="title2" value="<?php echo e($post->title2); ?>" placeholder="Additional Image Title"/>
                                    <textarea name="body2" id="article-ckeditorr" class="form-control" rows="5" placeholder="Additional Body Text"><?php echo e($post->body2); ?></textarea>
                                    <br>
                                    <label>Image 2</label>
                                    <input type="file" class="upfiles" name="cover_img2">
                                    <br>
                                    <label>Image 3</label>
                                    <input type="file" class="upfiles" name="cover_img3">
                                    <br><br>
                                    <button type="submit" name="sub_action" class="btn btn-primary" value="edit_post"><i class="fa fa-save"></i> &nbsp; Update</button>
                                    
                                </form>
                    
                            </div>
                          
                       
                    
                    
                </div>
                </div>
            </div>
      </div>

    </div>
</div>

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>