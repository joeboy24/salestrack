<?php /* /Users/klasique/abundantlife/resources/views/pages/dash/tithes.blade.php */ ?>
<?php $__env->startSection('search'); ?>
  <input type="text" value="" class="form-control" id="search" name="search" placeholder="Search Tithe...">
  <button type="submit" class="btn btn-white btn-round btn-just-icon">
    <i class="material-icons">search</i>
    <div class="ripple-container"></div>
  </button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item  ">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="material-icons">person</i>
          <p>Users</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/members">
          <i class="fa fa-users"></i>
          <p>Members</p>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="/tithes">
          <i class="material-icons">content_paste</i>
          <p>Tithe</p>
        </a>
      </li>
      <!--li class="nav-item ">
        <a class="nav-link" href="./icons.html">
          <i class="material-icons">bubble_chart</i>
          <p>Icons</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/galleryview">
          <i class="material-icons">image</i>
          <p>Gallery</p>
        </a>
      <li class="nav-item ">
        <a class="nav-link" href="/posts">
          <i class="material-icons">library_books</i>
          <p>Posts</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./map.html">
          <i class="material-icons">location_ons</i>
          <p>Maps</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./notifications.html">
          <i class="material-icons">notifications</i>
          <p>Notifications</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./rtl.html">
          <i class="material-icons">language</i>
          <p>RTL Support</p>
        </a>
      </li-->
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">     

      <div class="row">
        <div class="col-md-12">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">TITHE</h4>
              <p class="card-category"> Here is a list of all tithe records</p>
            </div>
            <div class="card-body">
              <form action="<?php echo e(action('TithesController@store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-info pull-right" name="store_action" value="create_tithe" onclick="return confirm('Are you sure you want to create tithe records for this year?');"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Create <?php echo e(date("Y")); ?> Tithe Records</button>
              </form>
              <div class="table-responsive">


                            <?php if(count($tithes) > 0): ?>
                            <table class="table">
                              <thead class=" text-primary">
                                <th>ID</th>
                                <th>Fullname</th>
                                <th>Jan</th>
                                <th>Feb</th>
                                <th>Mar</th>
                                <th>Apr</th>
                                <th>May</th>
                                <th>Jun</th>
                                <th>Jul</th>
                                <th>Aug</th>
                                <th>Sep</th>
                                <th>Oct</th>
                                <th>Nov</th>
                                <th>Dec</th>
                                <th>Total</th>
                                <th>Year</th>
                                <th class="ryt">
                                  Actions
                                </th>
                              </thead>
                              <tbody id="tb">
                              <?php $__currentLoopData = $tithes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tithe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($tithe->del != 'yes'): ?>
                                  <tr><td><?php echo e($tithe->id); ?></td>
                                    <td><?php echo e($tithe->fullname); ?></td>
                                    <td><?php echo e($tithe->jan); ?></td>
                                    <td><?php echo e($tithe->feb); ?></td>
                                    <td><?php echo e($tithe->mar); ?></td>

                                    <td><?php echo e($tithe->apr); ?></td>
                                    <td><?php echo e($tithe->may); ?></td>
                                    <td><?php echo e($tithe->jun); ?></td>

                                    <td><?php echo e($tithe->jul); ?></td>
                                    <td><?php echo e($tithe->aug); ?></td>
                                    <td><?php echo e($tithe->sep); ?></td>

                                    <td><?php echo e($tithe->oct); ?></td>
                                    <td><?php echo e($tithe->nov); ?></td>
                                    <td><?php echo e($tithe->dec); ?></td>
                                    <td>
                                      <?php echo e($tithe->jan + $tithe->feb + $tithe->mar + $tithe->apr + $tithe->may + $tithe->jun + $tithe->jul + $tithe->aug + $tithe->sep + $tithe->oct + $tithe->nov + $tithe->dec); ?>

                                    </td>
                                    <td><?php echo e($tithe->year); ?></td>

                                    <td class="ryt">
                                      <form action="<?php echo e(action('TithesController@update', $tithe->id)); ?>" method="POST">
                                        <input type="hidden" name="_method" value="PUT">
                                        <?php echo csrf_field(); ?>

                                        <a href="" title="Edit" class="edit" data-toggle="modal" data-target="#edit_<?php echo e($tithe->id); ?>"><i class="fa fa-pencil"></i></a>
                                        <!--textarea class="form-control" id="article-ckeditor" name="body" placeholder="Body/Text" rows="5"></textarea-->
                                    

                                        <div class="modal fade" id="edit_<?php echo e($tithe->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog modtop" role="document">
                                            <div class="modal-content">
                                                
                                                <div class="card card-profile">
                                                  <div class="card-avatar">
                                                    <a href="#pablo">
                                                    <img class="img" src="/storage/members_imgs/" />
                                                    </a>
                                                  </div>
                                                  <div class="card-body">
                                                    <h6 class="card-category text-gray"> Department</h6>
                                                    <h4 class="card-title"> FULLNAME</h4>

                                                    <table class="user_view_tbl">
                                                      <tbody>

                                                        <tr class="tbl_tr"><td class="tl">January</td><td class="tr">
                                                          <input type="number" class="form-control" name="jan" placeholder="GhC - " value="<?php echo e($tithe->jan); ?>"/> 
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">February</td><td class="tr">
                                                          <input type="number" class="form-control" name="feb" placeholder="GhC - " value="<?php echo e($tithe->feb); ?>"/> 
                                                        </td></tr>
                                                        
                                                        <tr class="tbl_tr"><td class="tl">March</td><td class="tr">
                                                          <input type="number" class="form-control" name="mar" placeholder="GhC - " value="<?php echo e($tithe->mar); ?>"/> 
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">April</td><td class="tr">
                                                          <input type="number" class="form-control" name="apr" placeholder="GhC - " value="<?php echo e($tithe->apr); ?>"/> 
                                                        </td></tr>
                                                        
                                                        <tr class="tbl_tr"><td class="tl">May</td><td class="tr">
                                                          <input type='number' name="may" class="form-control" placeholder="GhC - " value="<?php echo e($tithe->may); ?>"/>
                                                        </td></tr>
                                                        
                                                        <tr class="tbl_tr"><td class="tl">June</td><td class="tr">
                                                          <input type="number" class="form-control" name="jun" placeholder="GhC - " value="<?php echo e($tithe->jun); ?>"/>
                                                        </td></tr>
                                                        
                                                        <tr class="tbl_tr"><td class="tl">July</td><td class="tr">
                                                          <input type="number" class="form-control" name="jul" placeholder="GhC - " value="<?php echo e($tithe->jul); ?>"/>
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">August</td><td class="tr">
                                                          <input type="number" class="form-control" name="aug" placeholder="GhC - " value="<?php echo e($tithe->aug); ?>"/>
                                                        </td></tr>

                                                        <tr><td class="tl">September</td><td class="tr">
                                                          <input type="number" name="sep" class="form-control" placeholder="GhC - " value="<?php echo e($tithe->sep); ?>"/>
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">October</td><td class="tr">
                                                          <input type="number" class="form-control" name="oct" placeholder="GhC - " value="<?php echo e($tithe->oct); ?>"/>
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">November</td><td class="tr">
                                                          <input type="number" class="form-control" name="nov" placeholder="GhC - " value="<?php echo e($tithe->nov); ?>"/>
                                                        </td></tr>

                                                        <tr><td class="tl">December</td><td class="tr">
                                                          <input type="number" name="dec" class="form-control" placeholder="GhC - " value="<?php echo e($tithe->dec); ?>"/>
                                                        </td></tr>

                                                      </tbody>
                                                    </table>

                                                    <!--p class="card-description">
                                                      Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                                                    </p-->
                                                  </div>
                                                </div>
                                                
                                                <div class="modal-footer">
                                                  <button type="submit" class="btn btn-primary" name="sub_action" value="update_tithe" onclick="return confirm('Are you sure you want to update this tithe record?');"><i class="fa fa-save"></i> &nbsp; Update Details</button>
                                                </div>

                                            </div>
                                      
                                          </div>
                                        </div>

                                        
                                      </form>
                                    </td>
                                  </tr>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              </tbody>
                            </table>

                            <?php echo e($tithes->links()); ?>


                            <?php else: ?>
                              <p>No Tithe Record Created</p>
                            <?php endif; ?>

                            <!--tr><td>Precious Atti</td>
                              <td>Male</td>
                              <td>Media</td>
                              <td>Maturity Class</td>
                              <td>+4471928534274123</td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <a href="" title="Edit" class="edit"><i class="fa fa-pencil"></i></a>
                                <button type="button" class="view2" title="Delete" data-toggle="modal" data-target=""><i class="fa fa-folder-open"></i></button>
                              </form>
                              </td>
                            </tr>

                            <tr><td>John Doe</td>
                              <td>Male</td>
                              <td>Media</td>
                              <td>Maturity Class</td>
                              <td>+4471928534274123</td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <a href="" title="Edit" class="edit"><i class="fa fa-pencil"></i></a>
                                <button type="button" class="view2" title="Delete" data-toggle="modal" data-target=""><i class="fa fa-folder-open"></i></button>
                               </form>
                              </td>
                            </tr>

                            <tr><td>David Mensah</td>
                              <td>Male</td>
                              <td>Media</td>
                              <td>Maturity Class</td>
                              <td>+4471928534274123</td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <a href="" title="Edit" class="edit"><i class="fa fa-pencil"></i></a>
                                <button type="button" class="view2" title="Delete" data-toggle="modal" data-target=""><i class="fa fa-folder-open"></i></button>
                              </form>
                              </td>
                            </tr-->

                        


                        <!--Pagination-->

              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

<script type="text/javascript">
    $('#search').on('keyup',function(){
        $value=$(this).val();
        $.ajax({
            type : 'get',
            url : '<?php echo e(URL::to('searchtithe')); ?>',
            data:{'search':$value},
            success:function(data){
            $('#tb').html(data);
            }
        });
    })
</script>
<script type="text/javascript">
    $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>