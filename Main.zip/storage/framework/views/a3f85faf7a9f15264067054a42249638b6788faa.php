<?php /* /Users/jbazz/Documents/Lara/abundantlife/resources/views/pages/dash/members.blade.php */ ?>
<?php $__env->startSection('search'); ?>
  <input type="text" value="" class="form-control" id="search" name="search" placeholder="Search...">
  <button type="submit" class="btn btn-white btn-round btn-just-icon">
    <i class="material-icons">search</i>
    <div class="ripple-container"></div>
  </button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item  ">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="material-icons">person</i>
          <p>Users</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/department">
          <i class="material-icons">assignment</i>
          <p>Departments</p>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="/members">
          <i class="fa fa-users"></i>
          <p>Members</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/tithes">
          <i class="material-icons">content_paste</i>
          <p>Tithe</p>
        </a>
      </li>
      <!--li class="nav-item">
        <a class="nav-link" href="/galleryview">
          <i class="material-icons">image</i>
          <p>Gallery</p>
        </a>
      <li class="nav-item ">
        <a class="nav-link" href="/posts">
          <i class="material-icons">library_books</i>
          <p>Posts</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./icons.html">
          <i class="material-icons">bubble_chart</i>
          <p>Icons</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./map.html">
          <i class="material-icons">location_ons</i>
          <p>Maps</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./notifications.html">
          <i class="material-icons">notifications</i>
          <p>Notifications</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./rtl.html">
          <i class="material-icons">language</i>
          <p>RTL Support</p>
        </a>
      </li-->
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">     

      <div class="row">
        <div class="col-md-12">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">MEMBERS</h4>
              <p class="card-category"> Here is a list of all church members</p>
            </div>
            <div class="card-body">
              <button type="submit" class="btn btn-success pull-right" data-toggle="modal" data-target="#memberModal"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Add Member</button>
              <div class="table-responsive">


                            <?php if(count($members) > 0): ?>
                            <table class="table">
                              <thead class=" text-primary">
                                <th>ID</th>
                                <th>Fullname</th>
                                <th>Gender</th>
                                <th>Birth Date</th>
                                <th>Status</th>
                                <th>Contact</th>
    
                                <th>Department</th>
                                <th>Ministry</th>
                                <th>Residence</th>
    
                                <th>User</th>
                                <th class="ryt">
                                  Actions
                                </th>
                              </thead>
                              <tbody id="tb">
                              <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($member->del == 'no'): ?>
                                  <tr><td><?php echo e($member->id); ?></td>
                                    <td><?php echo e($member->fname.' '.$member->sname); ?></td>
                                    <td><?php echo e($member->sex); ?></td>
                                    <td><?php echo e($member->dob); ?></td>
                                    <td><?php echo e($member->mstatus); ?></td>
                                    <td><?php echo e($member->contact); ?></td>

                                    <td><?php echo e($member->department); ?></td>
                                    <td><?php echo e($member->ministry); ?></td>
                                    <td><?php echo e($member->residence); ?></td>
                                    
                                    

                                    <td><?php echo e($member->user_id); ?></td>



                                    <td class="ryt">
                                      <form action="<?php echo e(action('MembersController@update', $member->id)); ?>" method="POST">
                                        <input type="hidden" name="_method" value="PUT">
                                        <?php echo csrf_field(); ?>

                                        <button type="submit" name="sub_action" value="del" rel="tooltip" title="Delete Record" class="close2" onclick="return confirm('Are you sure you want to delete this record?');"><i class="fa fa-close"></i></button>
                                        <a href="" class="edit" data-toggle="modal" rel="tooltip" title="Edit Record" data-target="#edit_<?php echo e($member->member_id); ?>"><i class="fa fa-pencil"></i></a>
                                        <button type="button" class="view2" rel="tooltip" title="View Record" data-toggle="modal" data-target="#<?php echo e($member->member_id); ?>"><i class="fa fa-folder-open"></i></button>
                                        <!--textarea class="form-control" id="article-ckeditor" name="body" placeholder="Body/Text" rows="5"></textarea-->
                                        <input type="hidden" class="form-control" name="mid" value="<?php echo e($member->member_id); ?>"/> 
                                                        

                                        <div class="modal fade" id="<?php echo e($member->member_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog modtop" role="document">
                                            <div class="modal-content">
                                                <div class="card card-profile">
                                                  <div class="card-avatar">
                                                    <a href="#pablo">
                                                    <img class="img" src="/storage/members_imgs/<?php echo e($member->photo); ?>" />
                                                    </a>
                                                  </div>
                                                  <div class="card-body">
                                                    <h6 class="card-category text-gray"><?php echo e($member->department); ?> Department</h6>
                                                    <h4 class="card-title"><?php echo e($member->fname.' '.$member->sname); ?></h4>

                                                    <table class="user_view_tbl">
                                                      <tbody>
                                                        <tr class="tbl_tr"><td class="tl">Ministry</td><td class="tr"><?php echo e($member->ministry); ?> Ministry</td></tr>
                                                        <tr class="tbl_tr"><td class="tl">Gender</td><td class="tr"><?php echo e($member->sex); ?></td></tr>
                                                        <tr class="tbl_tr"><td class="tl">Date of Birth</td><td class="tr"><?php echo e($member->dob); ?></td></tr>
                                                        <tr class="tbl_tr"><td class="tl">Marital Status</td><td class="tr"><?php echo e($member->mstatus); ?></td></tr>
                                                        <tr class="tbl_tr"><td class="tl">Contact</td><td class="tr"><?php echo e($member->contact); ?></td></tr>
                                                        <tr class="tbl_tr"><td class="tl">Email</td><td class="tr"><?php echo e($member->email); ?></td></tr>
                                                        <tr class="tbl_tr"><td class="tl">Residence</td><td class="tr"><?php echo e($member->residence); ?></td></tr>

                                                        <tr><td class="tl">Address</td><td class="tr"><?php echo e($member->address); ?></td></tr>
                                                      </tbody>
                                                    </table>

                                                    <!--p class="card-description">
                                                      Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                                                    </p-->
                                                  </div>
                                                </div>
                                            </div>
                                      
                                          </div>
                                        </div>


                                        <div class="modal fade" id="edit_<?php echo e($member->member_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog modtop" role="document">
                                            <div class="modal-content">
                                                
                                                <div class="card card-profile">
                                                  <div class="card-avatar">
                                                    <a href="#pablo">
                                                    <img class="img" src="/storage/members_imgs/<?php echo e($member->photo); ?>" />
                                                    </a>
                                                  </div>
                                                  <div class="card-body">
                                                    <h6 class="card-category text-gray"><?php echo e($member->department); ?> Department</h6>
                                                    <h4 class="card-title"><?php echo e($member->fname.' '.$member->sname); ?></h4>

                                                    <table class="user_view_tbl">
                                                      <tbody>

                                                        <tr class="tbl_tr"><td class="tl">Firstname</td><td class="tr">
                                                          <input type="text" class="form-control" name="fname" placeholder="Firstname" value="<?php echo e($member->fname); ?>" required/> 
                                                          <input type="hidden" class="form-control" name="mid" value="<?php echo e($member->member_id); ?>"/> 
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">Other names</td><td class="tr">
                                                          <input type="text" class="form-control" name="sname" placeholder="Other names" value="<?php echo e($member->sname); ?>" required/> 
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">Ministry</td><td class="tr">
                                                          <select name="min" class="form-control" id="min" required>
                                                            <option>Adult</option>
                                                            <option>Youth</option>
                                                            <option>Children</option>
                                                          </select>
                                                        </td></tr>
                                                        
                                                        <tr class="tbl_tr"><td class="tl">Department</td><td class="tr">
                                                          <select name="dept" class="form-control" id="dept" required>
                                                            <?php if(count($deptms) > 0): ?>
                                                              <?php $__currentLoopData = $deptms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($dept->del != 'yes'): ?>
                                                                  <option><?php echo e($dept->name); ?></option>
                                                                <?php endif; ?>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                          </select>
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">Gender</td><td class="tr">
                                                          <select name="sex" class="form-control" id="sex" required>
                                                            <option>Male</option>
                                                            <option>Female</option>
                                                          </select>  
                                                        </td></tr>
                                                        
                                                        <tr class="tbl_tr"><td class="tl">Date of Birth</td><td class="tr">
                                                          <div class="form-group">
                                                            <input type='date' name="dob" class="form-control" value="<?php echo e($member->dob); ?>" required/>
                                                          </div>
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">Marital Status</td><td class="tr">
                                                          <select name="mstatus" class="form-control" id="mstatus" required>
                                                            <option>Single</option>
                                                            <option>Married</option>
                                                            <option>Divorced</option>
                                                            <option>Widow/er</option>
                                                          </select>
                                                        </td></tr>
                                                        
                                                        <tr class="tbl_tr"><td class="tl">Contact</td><td class="tr">
                                                          <input type="number" class="form-control" name="contact" placeholder="Contact No." value="<?php echo e($member->contact); ?>" required/>
                                                        </td></tr>
                                                        
                                                        <tr class="tbl_tr"><td class="tl">Email</td><td class="tr">
                                                          <input type="text" class="form-control" name="email" placeholder="Email" value="<?php echo e($member->email); ?>" required/>
                                                        </td></tr>

                                                        <tr class="tbl_tr"><td class="tl">Residence</td><td class="tr">
                                                          <input type="text" class="form-control" name="residence" placeholder="Place of Recidence" value="<?php echo e($member->residence); ?>" required/>
                                                        </td></tr>

                                                        <tr><td class="tl">Address</td><td class="tr">
                                                          <textarea name="address" id="article-ckeditorr" class="form-control" placeholder="address" rows="2" required><?php echo e($member->address); ?></textarea>
                                                        </td></tr>

                                                      </tbody>
                                                    </table>

                                                    <!--p class="card-description">
                                                      Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                                                    </p-->
                                                  </div>
                                                </div>
                                                
                                                <div class="modal-footer">
                                                  <button type="submit" class="btn btn-primary" name="sub_action" value="update_member" onclick="return confirm('Are you sure you want to update this member record?');"><i class="fa fa-save"></i> &nbsp; Update Details</button>
                                                </div>

                                            </div>
                                      
                                          </div>
                                        </div>
                                        
                                      </form>
                                    </td>
                                  </tr>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                            <?php else: ?>
                              <p>No Member Registered</p>
                            <?php endif; ?>

                            <!--tr><td>Precious Atti</td>
                              <td>Male</td>
                              <td>Media</td>
                              <td>Maturity Class</td>
                              <td>+4471928534274123</td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <a href="" title="Edit" class="edit"><i class="fa fa-pencil"></i></a>
                                <button type="button" class="view2" title="Delete" data-toggle="modal" data-target=""><i class="fa fa-folder-open"></i></button>
                              </form>
                              </td>
                            </tr>

                            <tr><td>John Doe</td>
                              <td>Male</td>
                              <td>Media</td>
                              <td>Maturity Class</td>
                              <td>+4471928534274123</td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <a href="" title="Edit" class="edit"><i class="fa fa-pencil"></i></a>
                                <button type="button" class="view2" title="Delete" data-toggle="modal" data-target=""><i class="fa fa-folder-open"></i></button>
                               </form>
                              </td>
                            </tr>

                            <tr><td>David Mensah</td>
                              <td>Male</td>
                              <td>Media</td>
                              <td>Maturity Class</td>
                              <td>+4471928534274123</td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <a href="" title="Edit" class="edit"><i class="fa fa-pencil"></i></a>
                                <button type="button" class="view2" title="Delete" data-toggle="modal" data-target=""><i class="fa fa-folder-open"></i></button>
                              </form>
                              </td>
                            </tr-->

                        


                        <!--Pagination-->

              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>


  
  <div class="modal fade" id="memberModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Add Member Here</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form action="<?php echo e(action('MembersController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <!--label for="cat-title" class="col-form-label">Title:</label-->
              <input type="text" class="form-control" name="fname" placeholder="Firstname" required/>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="sname" placeholder="Other names" required/>
            </div>
            <div class="form-group">
              <label for="" class="col-form-label smalllable">Date of Birth: </label>
            <input type='date' class="form-control" name="dob" required/>
            </div>
            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Gender:</label>
              <select name="sex" class="form-control" id="sex">
                <option>Male</option>
                <option>Female</option>
              </select>
              <label for="recipient-name" class="col-form-label">Marital Status:</label>
              <select name="mstatus" class="form-control" id="mstatus">
                <option>Single</option>
                <option>Married</option>
                <option>Divorced</option>
                <option>Widow/er</option>
              </select>

              <label for="dept" class="col-form-label">Department:</label>
              <select name="dept" class="form-control" id="dept" required>
                <?php if(count($deptms) > 0): ?>
                  <?php $__currentLoopData = $deptms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($dept->del != 'yes'): ?>
                      <option><?php echo e($dept->name); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>

              <label for="min" class="col-form-label">Ministry:</label>
              <select name="min" class="form-control" id="min" required>
                <option>Adult</option>
                <option>Youth</option>
                <option>Children</option>
              </select>

            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="contact" placeholder="Contact No." required/>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="email" placeholder="Email" />
            </div>
            <div class="form-group">
              <textarea name="address" id="article-ckeditorr" class="form-control" placeholder="Address" rows="2"></textarea>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="residence" placeholder="Place of Recidence" required/>
            </div>

            <div class="">
              <label class="upfiles">Upload Photo: &nbsp; </label>
              <input type="file" name="member_img" required>
            </div>
            
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary" name="store_action" value="admi_create_member"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>

        </div>
        <!--div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Send message</button>
        </div-->
      </div>
    </div>
  </div>

<script type="text/javascript">
    $('#search').on('keyup',function(){
        $value=$(this).val();
        $.ajax({
            type : 'get',
            url : '<?php echo e(URL::to('search')); ?>',
            data:{'search':$value},
            success:function(data){
            $('#tb').html(data);
            }
        });
    })
</script>
<script type="text/javascript">
    $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>