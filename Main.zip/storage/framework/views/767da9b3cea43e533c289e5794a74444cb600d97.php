<?php /* /Users/klasique/lara53/resources/views/pages/dash/tithe.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item  ">
        <a class="nav-link" href="./dashboard.html">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/dashuser">
          <i class="material-icons">person</i>
          <p>Users</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/members">
          <i class="fa fa-users"></i>
          <p>Members</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/galleryview">
          <i class="material-icons">image</i>
          <p>Gallery</p>
        </a>
      <li class="nav-item ">
        <a class="nav-link" href="/posts">
          <i class="material-icons">library_books</i>
          <p>Posts</p>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="./tithe">
          <i class="material-icons">content_paste</i>
          <p>Tithe</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./icons.html">
          <i class="material-icons">bubble_chart</i>
          <p>Icons</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./map.html">
          <i class="material-icons">location_ons</i>
          <p>Maps</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./notifications.html">
          <i class="material-icons">notifications</i>
          <p>Notifications</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./rtl.html">
          <i class="material-icons">language</i>
          <p>RTL Support</p>
        </a>
      </li>
      <li class="nav-item active-pro ">
        <a class="nav-link" href="./upgrade.html">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">     

      <div class="row">
        <div class="col-md-12">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">Tithe</h4>
              <p class="card-category"> Find Tithe Records Here</p>
            </div>
            <div class="card-body">
              <div class="table-responsive">

                
                        <table class="table">
                          <thead class=" text-primary">
                            <th>Id</th>
                            <th>Fullname</th>
                            <th>Year</th>
                            <th>Jan</th>
                            <th>Feb</th>
                            <th>Mar</th>
                            <th>Apr</th>
                            <th>May</th>
                            <th>Jun</th>
                            <th>Jul</th>
                            <th>Aug</th>
                            <th>Sep</th>
                            <th>Oct</th>
                            <th>Nov</th>
                            <th>Dec</th>
                            <th class="ryt">
                              Actions
                            </th>
                          </thead>
                          <tbody>
                            <tr><td>01</td>
                              <td>Joeboy Bass</td>
                              <td>2020</td>
                              <td>7,700</td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <button type="button" class="view3" title="View" data-toggle="modal" data-target="<?php echo e('#hold1'); ?>"><i class="fa fa-pencil"></i></button>
                                <!--textarea class="form-control" id="article-ckeditor" name="body" placeholder="Body/Text" rows="5"></textarea-->
                              </form>


                              <div class="modal fade" id="<?php echo e('hold1'); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modtop" role="document">
                                  <div class="modal-content">
                                      <div class="card card-profile">
                                        
                                        <div class="card-body">
                                          <h6> </h6>
                                          <h4 class="card-title">Joeboy Bass</h4>
                                          <h6 class="card-category text-gray">2020 - Tithe Report</h6>

                                          <form action="<?php echo e(action('PostsController@store')); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>


                                            <table class="user_view_tbl">
                                              <thead class="tithe_head">
                                                <th>MONTH</th>
                                                <th>AMOUNT</th>
                                              </thead>
                                              <tbody>
                                                <tr class="tbl_tr"><td class="tl">January</td><td class="tr">
                                                  <input type="text" class="form-control" name="jan" value=" GhC 7,700 " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">February</td><td class="tr">
                                                  <input type="text" class="form-control" name="feb" placeholder=" - " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">March</td><td class="tr">
                                                  <input type="text" class="form-control" name="mar" placeholder=" - " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">April</td><td class="tr">
                                                  <input type="text" class="form-control" name="apr" placeholder=" - " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">May</td><td class="tr">
                                                  <input type="text" class="form-control" name="may" placeholder=" - " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">June</td><td class="tr">
                                                  <input type="text" class="form-control" name="jun" placeholder=" - " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">July</td><td class="tr">
                                                  <input type="text" class="form-control" name="jul" placeholder=" - " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">August</td><td class="tr">
                                                  <input type="text" class="form-control" name="aug" placeholder=" - " required/>
                                                </td></tr>
                                                <tr class="tbl_tr"><td class="tl">September</td><td class="tr">
                                                  <input type="text" class="form-control" name="sep" placeholder=" - " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">October</td><td class="tr">
                                                  <input type="text" class="form-control" name="oct" placeholder=" - " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">November</td><td class="tr">
                                                  <input type="text" class="form-control" name="nov" placeholder=" - " required/>
                                                </td></tr>

                                                <tr class="tbl_tr"><td class="tl">December</td><td class="tr">
                                                  <input type="text" class="form-control" name="dec" placeholder=" - " required/>
                                                </td></tr>

                                              </tbody>
                                            </table>
                                            <div class="modal-footer">
                                              <button type="submit" class="btn btn-success" name="store_action" value="update_tithe"><i class="fa fa-save"></i> &nbsp; Save</button>
                                            </div>

                                          </form>

                                          <!--p class="card-description">
                                            Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                                          </p-->
                                        </div>
                                      </div>
                                  </div>
                             
                                </div>
                              </div>

                              </td>
                            </tr>

                            <tr><td>02</td>
                              <td>Precious Atti</td>
                              <td>2020</td>
                              <td>9,300</td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <button type="button" class="view3" title="View" data-toggle="modal" data-target="<?php echo e('#hold1'); ?>"><i class="fa fa-pencil"></i></button>
                              </form>
                              </td>
                            </tr>

                            <tr><td>03</td>
                              <td>John Doe</td>
                              <td>2020</td>
                              <td>3,500</td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <button type="button" class="view3" title="View" data-toggle="modal" data-target="<?php echo e('#hold1'); ?>"><i class="fa fa-pencil"></i></button>
                                <!--textarea class="form-control" id="article-ckeditor" name="body" placeholder="Body/Text" rows="5"></textarea-->
                              </form>
                              </td>
                            </tr>

                            <tr><td>04</td>
                              <td>David Mensah</td>
                              <td>2020</td>
                              <td>11,700</td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td> - </td>
                              <td class="ryt">
                              <form action="" method="POST" class="float-right">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                <button type="submit" name="sub_action" value="del" class="close2" title="Open"><i class="fa fa-close"></i></button>
                                <button type="button" class="view3" title="View" data-toggle="modal" data-target="<?php echo e('#hold1'); ?>"><i class="fa fa-pencil"></i></button>
                                <!--textarea class="form-control" id="article-ckeditor" name="body" placeholder="Body/Text" rows="5"></textarea-->
                              </form>
                              </td>
                            </tr>
                          </tbody>
                        </table>

                        


                        <!--Pagination-->

              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>