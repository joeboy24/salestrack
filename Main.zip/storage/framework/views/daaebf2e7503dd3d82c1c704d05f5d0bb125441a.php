<?php /* /Users/klasique/lara53/resources/views/posts/try1.blade.php */ ?>



                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comment-list">
                                <div class="single-comment justify-content-between d-flex">
                                    <div class="user justify-content-between d-flex">
                                        <div class="thumb">
                                            <img src="/maindir/image/blog/c1.jpg" alt="">
                                        </div>
                                        <div class="desc">
                                            <h5><a href="/maindir/#">Emilly Blunt</a></h5>
                                            <p class="date">December 4, 2017 at 3:12 pm </p>
                                            <p class="comment">
                                                <?php echo e($comment->cbody); ?> Never say goodbye till the end comes!
                                            </p>
                                        </div>
                                    </div>
                                    <div class="reply-btn">
                                           <a href="/maindir/" class="btn-reply text-uppercase">reply</a> 
                                    </div>
                                </div>
                            </div>	
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>