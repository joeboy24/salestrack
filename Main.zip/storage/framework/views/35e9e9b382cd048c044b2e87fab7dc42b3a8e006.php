<?php /* /Users/jbazz/Documents/Lara/PivoResults/resources/views/pages/timetable.blade.php */ ?>
<html>

<head>
</head>

<body>

    


    <h3><?php echo e($soln); ?> | </h3>

</body>

</html>