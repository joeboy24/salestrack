<?php /* /Users/jbazz/Documents/Lara/PivoResults/resources/views/pages/uploadtest.blade.php */ ?>
<?php $__env->startSection('content'); ?>
   <!--================Banner Area =================-->
        <section class="banner_area">
            <div class="booking_table d_flex align-items-center">
            	<div class="overlay bg-parallax" data-stellar-ratio="0.9" data-stellar-vertical-offset="0" data-background=""></div>
				<div class="container">
					<div class="banner_content text-center">
						<h6>PivoApps</h6>
						<h2>School Track</h2>
						<p>Access all of our products from<br> Any platform of your choice to make work more easier.</p>
						<a href="" data-toggle="modal" data-target="#reg" class="btn theme_btn button_hover">Register</a>
					</div>
				</div>
            </div>
        </section>
        <!--================Banner Area =================-->
        
        <!--================ Accomodation Area  =================-->
        <section class="accomodation_area section_gap">
            


            <div class="container">

                <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card bg-light mt-3">
                    <img class="img" src="/storage/app/public/tch_imgs/Lucy_1611703478" />
                    <div class="card-header">
                        Laravel 5.7 Import Export Excel to database Example - ItSolutionStuff.com
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="file" name="file" class="form-control">
                            <br>
                            <button class="btn btn-success">Import User Data</button>
                            <a class="btn btn-warning" href="<?php echo e(route('export')); ?>">Export User Data</a>
                        </form>
                    </div>
                </div>
            </div>


        </section>
        <!--================ Accomodation Area  =================-->
        
       
<?php $__env->stopSection(); ?>
        
     
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>