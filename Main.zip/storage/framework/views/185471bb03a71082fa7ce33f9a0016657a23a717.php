<?php /* /Users/klasique/lara53/resources/views/pages/insertForm.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xl-8 offset-xl-2">
        <a href="/posts" class="btn btn-default" role="button"><< Posts</a>
        <h1>Trial</h1>
        
        <form action="/insert" method="POST">
            <?php echo csrf_field(); ?>

            <label>Title</label>
            <input type="text" class="form-control" name="title" placeholder="Tittle" />
            <label>Body</label>
            <textarea class="form-control" name="body" placeholder="Body/Text" rows="5"></textarea>
            <input type="submit" class="btn btn-primary" name="submit" value="Submit" />
        </form>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>