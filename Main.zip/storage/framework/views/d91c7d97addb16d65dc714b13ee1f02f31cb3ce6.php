<?php /* /Users/jbazz/Documents/Lara/PivoResults/resources/views/pages/dash/reports.blade.php */ ?>
<?php $__env->startSection('sidebar-wrapper'); ?>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item ">
        <a class="nav-link" href="/dashboard">
          <i class="material-icons">dashboard</i>
          <p>Dashboard</p>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="/dashuser">
          <i class="material-icons">ballot</i>
          <p>Registry</p>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/department">
          <i class="material-icons">assignment</i>
          <p>Departments</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/members">
          <i class="fa fa-users"></i>
          <p>Members</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="/tithes">
          <i class="material-icons">content_paste</i>
          <p>Tithe</p>
        </a>
      </li>
      <!--li class="nav-item ">
        <a class="nav-link" href="/galleryview">
          <i class="material-icons">image</i>
          <p>Gallery</p>
        </a>
      <li class="nav-item ">
        <a class="nav-link" href="/posts">
          <i class="material-icons">library_books</i>
          <p>Posts</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./icons.html">
          <i class="material-icons">bubble_chart</i>
          <p>Icons</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./map.html">
          <i class="material-icons">location_ons</i>
          <p>Maps</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./notifications.html">
          <i class="material-icons">notifications</i>
          <p>Notifications</p>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="./rtl.html">
          <i class="material-icons">language</i>
          <p>RTL Support</p>
        </a>
      </li-->
      <li class="nav-item active-pro ">
        <a class="nav-link" href="#">
          <i class="material-icons">unarchive</i>
          <p>Upgrade to PRO</p>
        </a>
      </li>
    </ul>
  </div>  
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- End Navbar -->
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-10">

              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              

                <div class="form-group row mb-0">

                  <div class="col-md-9 offset-md-0">

                    <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>


                        <label for="recipient-name" class="col-form-label">Asign Teacher/Lecturer</label>
                        <select name="assign_tch" class="form-control sort" id="assign_tch">
                          <option>Teacher Name</option>
                          <?php if(count($teachers) > 0): ?>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($teacher->del != 'yes'): ?>
                                <option><?php echo e($teacher->fname.' '.$teacher->sname); ?></option>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </select>
    
                        <button type="submit" class="btn btn-primary" name="store_action" value="admi_create_crs"><i class="fa fa-save"></i> &nbsp; Save</button>
                      
                    </form>


                  </div>

                  <div class="col-md-3 offset-md-0">
                      <button type="submit" class="btn btn-info pull-right" name="store_action" value="create_trs"  data-toggle="modal" data-target="#trsModal"><i class="fa fa-users"></i> &nbsp; Register Staff</button>
                  </div>
                </div>

              

              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">All Registered Teachers</h4>
                  
                </div>
                <div class="card-body">
            
                  <div class="container">
                      <div class="row justify-content-center">

                    <?php if(count($teachers) > 0): ?>
                        <table class="table">
                          <thead class=" text-secondary">
                            <th></th>
                            <th>ID</th>
                            <th>Name</th>
                            <th>DOB</th>
                            <th>Gender</th>
                            <th>Role</th>
                            <th>Contact</th>
                            <th class="ryt">
                              Action
                            </th>
                          </thead>
                          <tbody>
                          <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr><td><?php echo e($t++); ?></td>
                                <td><?php echo e($teacher->tch_id); ?></td>
                                <td><?php echo e($teacher->fname.' '.$teacher->sname); ?></td>
                                <td><?php echo e($teacher->dob); ?></td>
                                <td><?php echo e($teacher->sex); ?></td>
                                <td><?php echo e($teacher->role.' ('.$teacher->role_desc.')'); ?></td>
                                <td><?php echo e($teacher->contact); ?></td>
                                <td class="ryt">
                                  <form action="<?php echo e(action('StudentController@destroy', $teacher->id)); ?>" method="POST">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <?php echo csrf_field(); ?>

                                    <button type="submit" name="sub_action" value="trs_del" rel="tooltip" title="Delete User" class="close2" onclick="return confirm('Are you sure you want to delete this record?');"><i class="fa fa-close"></i></button>
                                  </form>
                                </td>
                              </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                    <?php else: ?>
                      <p>No Staff Registered Yet</p>
                    <?php endif; ?>

            

                      </div>
                  </div>
                </div>
              </div>


            </div>



          </div>
        </div>
  </div>



  <div class="modal fade" id="crsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Register Subject/Course Here</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <!--label for="cat-title" class="col-form-label">Title:</label-->
              <input type="text" class="form-control" name="name" placeholder="Course Name" required/>
            </div>

            <div class="form-group">
              <textarea name="desc" id="article-ckeditorr" class="form-control" placeholder="Course Description" rows="3"></textarea>
            </div>

            <div class="form-group">
            
              <label for="recipient-name" class="col-form-label">Asign Teacher/Lecturer</label>
              <select name="assign_tch" class="form-control" id="assign_tch">
                <option>Not Assigned</option>
                <?php if(count($teachers) > 0): ?>
                  <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($teacher->del != 'yes'): ?>
                      <option><?php echo e($teacher->fname.' '.$teacher->sname); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>

            </div>
            
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary" name="store_action" value="admi_create_crs"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>

        </div>
        <!--div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Send message</button>
        </div-->
      </div>
    </div>
  </div>

  <div class="modal fade" id="trsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Add Staff Here</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <!--label for="cat-title" class="col-form-label">Title:</label-->
              <input type="text" class="form-control" name="fname" placeholder="Firstname" required/>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="sname" placeholder="Other names" required/>
            </div>
            
            <label for="" class="col-form-label smalllable">Date of Birth: </label>
            <div class="form-group">
            <input type='date' class="form-control" placeholder="YYYY-MM-DD" name="dob"/>
            </div>
            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Gender:</label>
              <select name="sex" class="form-control" id="sex">
                <option>Male</option>
                <option>Female</option>
              </select>
              <label for="recipient-name" class="col-form-label">Marital Status:</label>
              <select name="mstatus" class="form-control" id="mstatus">
                <option>Single</option>
                <option>Married</option>
                <option>Divorced</option>
                <option>Widow/er</option>
              </select>

              

            </div>

            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Role:</label>
              <select name="role" class="form-control" id="ROLE">
                <option>Teacher</option>
                <option>Other</option>
              </select>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="role_desc" placeholder="Role Description"/>
            </div>

            <div class="form-group">
              <input type="text" class="form-control" name="contact" placeholder="Contact No." required/>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="email" placeholder="Email" />
            </div>
            
            <div class="form-group">
              <input type="text" class="form-control" name="residence" placeholder="Place of Recidence"/>
            </div>

            <div class="">
              <label class="upfiles">Upload Photo: &nbsp; </label>
              <input type="file" name="tch_img" required>
            </div>
            
            <div class="modal-footer">
              <button type="submit" class="btn btn-info" name="store_action" value="admi_create_trs"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>

        </div>
        <!--div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Send message</button>
        </div-->
      </div>
    </div>
  </div>

  <div class="modal fade" id="clsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp; Confirm Class & Course Registeration</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <div class='col-md-10 offset-md-1'>
          <form action="<?php echo e(action('StudentController@store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            

            <div class="form-group">
             
              <label class="col-form-label">Choose Class</label>
              <select name="cls_name" class="form-control" id="cls_name">
                <option>Class 1</option>
                <option>Class 2</option>
                <option>Class 3A</option>
                <option>JHS 3</option>
              </select>
              
              <label class="col-form-label">Selected Subjects</label>
              <div class="form-group">
                <textarea name="sel_sub" id="txt_area" class="form-control myReadonly" placeholder="Course Description" rows="3" readonly></textarea>
              </div>

              <label class="col-form-label">Class Teacher/Lecturer</label>
              <select name="cls_tch" class="form-control" id="assign_tch">
                <option selected>Not Assigned</option>
                <option>Teacher 1</option>
                <option>Teacher 2</option>
                <option>Teacher 3</option>
              </select>

              

            </div>

            
      
            <div class="modal-footer">
              <button type="submit" class="btn btn-info" name="store_action" value="admi_create_cls"><i class="fa fa-save"></i> &nbsp; Save</button>
            </div>
          </form>
          </div>

        </div>
        <!--div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Send message</button>
        </div-->
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>