<?php /* /Users/jbazz/Documents/Lara/PivoResults/resources/views/pages/dash/registerme.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="/dashdir/img/apple-icon.png">
  <link rel="icon" type="image/png" href="/dashdir/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    AG - Admin
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="/dashdir/css/material-dashboard.css?v=2.1.1" rel="stylesheet" />
  <link rel="stylesheet" href="/maindir/css/style.css">
</head>

<body class="">
    



      <div class="content">
        <div class="container-fluid">    
          <div class="row">
            <div class="col-lg-10 offset-lg-1">
              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">REGISTER ME</h4>
                  <p class="card-category"> Abundant Life Center, Assemblies of God</p>
                </div>
                <div class="offset-lg-10 aglogo">
                  <img class="aglogo_img" src="/maindir/image/ag_des1.png" />
                </div>
                <div class="card-body topspace">
                  <div class="table-responsive">
    
                    
                    
                    <div class="registerme">

                      <form action="<?php echo e(action('MembersController@store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                          <!--label for="cat-title" class="col-form-label">Title:</label-->
                          <input type="text" class="form-control" name="fname" placeholder="Firstname" onchange="formdetails(this)" required/>
                        </div>
                        <div class="form-group">
                          <input type="text" class="form-control" name="sname" placeholder="Other names" required/>
                        </div>
                        <div class="form-group">
                          <label for="" class="col-form-label smalllable">Date of Birth: </label>
                          <input type='date' name="dob" class="form-control" required/>
                        </div>
                        <div class="form-group">
                          <label for="sex" class="col-form-label">Gender:</label>
                          <select name="sex" class="form-control" id="sex" required>
                            <option>Male</option>
                            <option>Female</option>
                          </select>
                          <label for="mstatus" class="col-form-label">Marital Status:</label>
                          <select name="mstatus" class="form-control" id="mstatus" required>
                            <option>Single</option>
                            <option>Married</option>
                            <option>Divorced</option>
                            <option>Widow/er</option>
                          </select>

                          <label for="dept" class="col-form-label">Department:</label>
                          <select name="dept" class="form-control" id="dept" required>

                            <?php if(count($deptms) > 0): ?>
                              <?php $__currentLoopData = $deptms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($dept->del != 'yes'): ?>
                                  <option><?php echo e($dept->name); ?></option>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                          </select>
                          <label for="min" class="col-form-label">Ministry:</label>
                          <select name="min" class="form-control" id="min" required>
                            <option>Adult</option>
                            <option>Youth</option>
                            <option>Children</option>
                          </select>
                        </div>
                        <div class="form-group">
                          <input type="tel" class="form-control" name="contact" placeholder="Contact No." required/>
                        </div>
                        <div class="form-group">
                          <input type="text" class="form-control" name="email" placeholder="Email"/>
                        </div>
                        <div class="form-group">
                          <textarea name="address" id="article-ckeditorr" class="form-control" placeholder="address" rows="2" required></textarea>
                        </div>
                        <div class="form-group">
                          <input type="text" class="form-control" name="residence" placeholder="Place of Recidence" required/>
                        </div>
            
                        <div class="">
                          <label class="upfiles">Upload Photo: &nbsp; </label>
                          <input type="file" name="member_img" required>
                        </div>
                        
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary" name="store_action" value="create_member"><i class="fa fa-save"></i> &nbsp; Save</button>
                        </div>
                      </form>
            
                    </div>
                    

    
                  </div>
                </div>
              </div>
            </div>
    
          </div>
        </div>
      </div>



      <footer class="footer">
        
      </footer>

  <!--   Core JS Files   -->
  <script src="/dashdir/js/core/jquery.min.js"></script>
  <script src="/dashdir/js/core/popper.min.js"></script>
  <script src="/dashdir/js/core/bootstrap-material-design.min.js"></script>
  <script src="/dashdir/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <script src="/dashdir/js/plugins/moment.min.js"></script>
  <!--  Plugin for Sweet Alert -->
  <script src="/dashdir/js/plugins/sweetalert2.js"></script>
  <!-- Forms Validations Plugin -->
  <script src="/dashdir/js/plugins/jquery.validate.min.js"></script>
  <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
  <script src="/dashdir/js/plugins/jquery.bootstrap-wizard.js"></script>
  <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="/dashdir/js/plugins/bootstrap-selectpicker.js"></script>
  <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
  <script src="/dashdir/js/plugins/bootstrap-datetimepicker.min.js"></script>
  <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
  <script src="/dashdir/js/plugins/jquery.dataTables.min.js"></script>
  <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="/dashdir/js/plugins/bootstrap-tagsinput.js"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="/dashdir/js/plugins/jasny-bootstrap.min.js"></script>
  <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
  <script src="/dashdir/js/plugins/fullcalendar.min.js"></script>
  <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
  <script src="/dashdir/js/plugins/jquery-jvectormap.js"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="/dashdir/js/plugins/nouislider.min.js"></script>
  <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
  <!-- Library for adding dinamically elements -->
  <script src="/dashdir/js/plugins/arrive.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="/dashdir/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="/dashdir/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="/dashdir/js/material-dashboard.js?v=2.1.1" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="/dashdir/demo/demo.js"></script>
  
</body>

</html>
