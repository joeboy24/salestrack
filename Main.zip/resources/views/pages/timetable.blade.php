<html>

<head>
</head>

<body>

    {{-- @foreach ($soln as $so)
     <h3>{{$so}} | </h3>
    @endforeach --}}


    <h3>{{$soln}} | </h3>

</body>

</html>