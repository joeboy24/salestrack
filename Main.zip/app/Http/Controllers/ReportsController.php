<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Company;
use App\Category;
use App\User;
use App\Cart;
use App\Item;
use App\Sale;
use App\Order;
use App\Expense;
use App\Waybill;
use App\SalesHistory;
use App\CompanyBranch;
use Exception;
use Session;

class ReportsController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(auth()->user()->status != 'Administrator'){
            return redirect('/dashboard'); 
        }
        //
        $c = 1;
        $date_from = $request->query('date_from');
        $date_to = $request->query('date_to');
        // if ($request->filled('date_from')) {
        if (!empty($date_from) && empty($date_to)) {
            # code...
            $sales = Sale::where('del', 'no')->where('created_at', 'LIKE', '%'.$date_from.'%')->orderBy('id', 'desc')->paginate(10);
            // Get Money Sums
            $cash = Sale::where('del', 'no')->where('pay_mode', 'cash')->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('tot');
            $cheque = Sale::where('del', 'no')->where('pay_mode', 'cheque')->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('tot');
            $momo = Sale::where('del', 'no')->where('pay_mode', 'Mobile Money')->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('tot');
            $sum_dbt = Sale::where('del', 'no')->where('pay_mode', 'Post Payment(Debt)')->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('tot');
            // Get sum Branch 1
            $b1_match = ['del' => 'no', 'user_bv' => 1 ];
            $b1 = Sale::where($b1_match)->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('tot');
            // Get sum Branch 2
            $b2_match = ['del' => 'no', 'user_bv' => 2 ];
            $b2 = Sale::where($b2_match)->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('tot');
            // Get sum Branch 3
            $b3_match = ['del' => 'no', 'user_bv' => 3 ];
            $b3 = Sale::where($b3_match)->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('tot');
            $expenses = Expense::where('del', 'no')->where('created_at', 'LIKE', '%'.$date_from.'%')->get();
            // return redirect('/reporting')->with('success', 'Yehh..! Filled From');

            // Get general profits
            $gp_match = ['del' => 'no'];
            $gen_profits = SalesHistory::where($gp_match)->where('updated_at', 'LIKE', '%'.$date_from.'%')->sum('profits');

            $prof_b1_match = ['del' => 'no', 'user_bv' => 1];
            $b1_profits = SalesHistory::where($prof_b1_match)->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('profits');

            $prof_b2_match = ['del' => 'no', 'user_bv' => 2];
            $b2_profits = SalesHistory::where($prof_b2_match)->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('profits');

            $prof_b3_match = ['del' => 'no', 'user_bv' => 3];
            $b3_profits = SalesHistory::where($prof_b3_match)->where('created_at', 'LIKE', '%'.$date_from.'%')->sum('profits');

        }elseif (empty($date_from) && !empty($date_to)) {
            return redirect('/reporting')->with('error', 'Oops..! Provide *Date From* in order to proceed');

        }elseif (!empty($date_from) && !empty($date_to)) {

            $sales = Sale::where('del', 'no')->whereBetween('created_at', [$date_from, $date_to])->orderBy('id', 'desc')->paginate(10);
            // Get Money Sums
            $cash = Sale::where('del', 'no')->where('pay_mode', 'cash')->whereBetween('created_at', [$date_from, $date_to])->sum('tot');
            $cheque = Sale::where('del', 'no')->where('pay_mode', 'cheque')->whereBetween('created_at', [$date_from, $date_to])->sum('tot');
            $momo = Sale::where('del', 'no')->where('pay_mode', 'Mobile Money')->whereBetween('created_at', [$date_from, $date_to])->sum('tot');
            $sum_dbt = Sale::where('del', 'no')->where('pay_mode', 'Post Payment(Debt)')->whereBetween('created_at', [$date_from, $date_to])->sum('tot');
            // Get sum Branch 1
            $b1_match = ['del' => 'no', 'user_bv' => 1 ];
            $b1 = Sale::where($b1_match)->whereBetween('created_at', [$date_from, $date_to])->sum('tot');
            // Get sum Branch 2
            $b2_match = ['del' => 'no', 'user_bv' => 2 ];
            $b2 = Sale::where($b2_match)->whereBetween('created_at', [$date_from, $date_to])->sum('tot');
            // Get sum Branch 3
            $b3_match = ['del' => 'no', 'user_bv' => 3 ];
            $b3 = Sale::where($b3_match)->whereBetween('created_at', [$date_from, $date_to])->sum('tot');
            $expenses = Expense::where('del', 'no')->whereBetween('created_at', [$date_from, $date_to])->get();
            // return redirect('/reporting')->with('success', 'Yehh..! Filled Both');

            // Get general profits
            $gp_match = ['del' => 'no'];
            $gen_profits = SalesHistory::where($gp_match)->whereBetween('created_at', [$date_from, $date_to])->sum('profits');

            $prof_b1_match = ['del' => 'no', 'user_bv' => 1 ];
            $b1_profits = SalesHistory::where($prof_b1_match)->whereBetween('created_at', [$date_from, $date_to])->sum('profits');

            $prof_b2_match = ['del' => 'no', 'user_bv' => 2 ];
            $b2_profits = SalesHistory::where($prof_b2_match)->whereBetween('created_at', [$date_from, $date_to])->sum('profits');

            $prof_b3_match = ['del' => 'no', 'user_bv' => 3 ];
            $b3_profits = SalesHistory::where($prof_b3_match)->whereBetween('created_at', [$date_from, $date_to])->sum('profits');

        }else{
            
            $sales = Sale::where('del', 'no')->where('created_at', 'LIKE', '%'.date("Y-m-d").'%')->orderBy('id', 'desc')->paginate(10);
            // Get Money Sums
            $cash = Sale::where('del', 'no')->where('pay_mode', 'cash')->where('created_at', 'LIKE', '%'.date("Y-m-d").'%')->sum('tot');
            $cheque = Sale::where('del', 'no')->where('pay_mode', 'cheque')->where('created_at', 'LIKE', '%'.date("Y-m-d").'%')->sum('tot');
            $momo = Sale::where('del', 'no')->where('pay_mode', 'Mobile Money')->where('created_at', 'LIKE', '%'.date("Y-m-d").'%')->sum('tot');
            $sum_dbt = Sale::where('del', 'no')->where('pay_mode', 'Post Payment(Debt)')->where('created_at', 'LIKE', '%'.date("Y-m-d").'%')->sum('tot');
            // Get sum Branch 1
            $b1_match = ['del' => 'no', 'user_bv' => 1 ];
            $b1 = Sale::where($b1_match)->where('created_at', 'LIKE', '%'.Session::get('date_today').'%')->sum('tot');
            // Get sum Branch 2
            $b2_match = ['del' => 'no', 'user_bv' => 2 ];
            $b2 = Sale::where($b2_match)->where('created_at', 'LIKE', '%'.Session::get('date_today').'%')->sum('tot');
            // Get sum Branch 3
            $b3_match = ['del' => 'no', 'user_bv' => 3 ];
            $b3 = Sale::where($b3_match)->where('created_at', 'LIKE', '%'.Session::get('date_today').'%')->sum('tot');
            $expenses = Expense::where('del', 'no')->where('created_at', 'LIKE', '%'.date("Y-m-d").'%')->get();


            // Get general profits
            $gp_match = ['del' => 'no'];
            $gen_profits = SalesHistory::where($gp_match)->where('updated_at', 'LIKE', '%'.Session::get('date_today').'%')->sum('profits');

            $prof_b1_match = ['del' => 'no', 'user_bv' => 1 ];
            $b1_profits = SalesHistory::where($prof_b1_match)->where('created_at', 'LIKE', '%'.Session::get('date_today').'%')->sum('profits');

            $prof_b2_match = ['del' => 'no', 'user_bv' => 2 ];
            $b2_profits = SalesHistory::where($prof_b2_match)->where('created_at', 'LIKE', '%'.Session::get('date_today').'%')->sum('profits');

            $prof_b3_match = ['del' => 'no', 'user_bv' => 3 ];
            $b3_profits = SalesHistory::where($prof_b3_match)->where('created_at', 'LIKE', '%'.Session::get('date_today').'%')->sum('profits');

        }

        $gross = $cash + $cheque + $momo + $sum_dbt;
        $net = $gross - $expenses->sum('expense_cost');

            // Set session variables
            Session::put('b1', $b1);
            Session::put('b2', $b2);
            Session::put('b3', $b3);
            Session::put('gross', $gross);
            Session::put('net', $net);
            Session::put('sales', $sales);
            Session::put('cash', $cash);
            Session::put('cheque', $cheque);
            Session::put('momo', $momo);
            Session::put('sum_dbt', $sum_dbt);
            Session::put('expenses', $expenses);
            Session::put('date_from', $date_from);
            Session::put('date_to', $date_to);

        $pass = [
            'c' => $c, 
            'b1' => $b1, 
            'b2' => $b2, 
            'b3' => $b3, 
            'cash' => $cash,
            'cheque' => $cheque,
            'momo' => $momo,
            'sum_dbt' => $sum_dbt,
            'sales' => $sales, 
            'b1_profits' => $b1_profits,
            'b2_profits' => $b2_profits,
            'b3_profits' => $b3_profits, 
            'gen_profits' => $gen_profits,
            'expenses' => $expenses
        ];
        return view('pages.dash.reportsview')->with($pass);
    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $order = Sale::find($id);
        $sales = $order->saleshistory->all();
        $user = User::find($order->user_id);

        $company = Company::find(1);
        $pass = [
            'count' => 1,
            'count2' => 1,
            'user' => $user,
            'order' => $order,
            'company' => $company,
            'sales' => $sales
        ];

        return view('pages.dash.single_invoice')->with($pass);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
